import os
from fastapi import APIRouter, Request, Form, status
from fastapi.responses import RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text,MetaData
from datetime import datetime

router = APIRouter()
templates = Jinja2Templates(directory="templates")

DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

engine = create_engine(DATABASE_URL)
metadata = MetaData()

@router.get("/templatedownload")
def templatedownload(request: Request):
    return templates.TemplateResponse("template_download.html", {"request": request})

@router.get("/template")
def form_page(request: Request,msg: str | None = None):
    with engine.connect() as conn:
        clients = conn.execute(
            text("select entity_value from public.aira_hierarchy where entity_type = 'Client'")
        ).fetchall()
        clients = [row[0] for row in clients]
    return templates.TemplateResponse("template_form.html", {
        "request": request,
        "clients": clients,
        "message": msg
    })

@router.get("/get-product-families/{client}")
def get_product_families(client: str):
    with engine.connect() as conn:
        families = conn.execute(text("""
            select entity_value from public.aira_hierarchy
            where parent = :client and entity_type = 'ProductFamily'
        """), {"client": client}).fetchall()
        families = [row[0] for row in families]
    return JSONResponse(content={"families": families})

@router.get("/get-products/{product_family}")
def get_products(product_family: str):
    with engine.connect() as conn:
        products = conn.execute(text("""
            select entity_value from public.aira_hierarchy
            where parent = :family and entity_type = 'Product'
        """), {"family": product_family}).fetchall()
        products = [row[0] for row in products]
    return JSONResponse(content={"products": products})

@router.post("/submit-template")
def submit_template(
    client: str = Form(...),
    productFamily: str = Form(...),
    product: str = Form(...),
    templateName: str = Form(...),
    outputTemplatePath: str = Form(...),
    templateStartRow: str = Form(...),
    templateStartColumn: str = Form(...)
):
    with engine.connect() as conn:
        insert_query = text("""
            INSERT INTO template 
            ("client", "productfamily", "product", "templatename", "version", "isactive", "createdon", "outputtemplatepath", "templatestartrow", "templatestartcolumn")
            VALUES
            (:client, :productFamily, :product, :templateName, :version, :isActive, :createdOn, :outputTemplatePath, :startRow, :startColumn)
        """)
        conn.execute(insert_query, {
            "client": client,
            "productFamily": productFamily,
            "product": product,
            "templateName": templateName,
            "version": 1,
            "isActive": True,
            "createdOn": datetime.utcnow(),
            "outputTemplatePath": outputTemplatePath,
            "startRow": templateStartRow,
            "startColumn": templateStartColumn
        })
        conn.commit()

    return RedirectResponse(url="/template?msg=Template+saved+successfully", status_code=status.HTTP_303_SEE_OTHER)

