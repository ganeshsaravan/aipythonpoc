from fastapi import APIRouter, Request, Form, Query
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text, MetaData
from sqlalchemy.exc import SQLAlchemyError
import os

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# DB config
DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

engine = create_engine(DATABASE_URL)
metadata = MetaData()

# -------------------------
# Helper: Sync identity sequence
# -------------------------
def sync_row_id_sequence():
    with engine.begin() as conn:
        conn.execute(text("""
            SELECT setval(
                pg_get_serial_sequence('public.aira_hierarchy', 'row_id'),
                COALESCE((SELECT MAX(row_id) FROM public.aira_hierarchy), 0) + 1,
                false
            );
        """))

# -------------------------
# Helper: fetch data
# -------------------------
def get_clients():
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT entity_value, row_id
            FROM public.aira_hierarchy
            WHERE entity_type = 'Client'
            ORDER BY entity_value
        """)).fetchall()
        return [{"name": r[0], "id": r[1]} for r in rows]

def get_families_by_client(client_name):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT entity_value, row_id
            FROM public.aira_hierarchy
            WHERE entity_type = 'ProductFamily' AND parent = :p
            ORDER BY entity_value
        """), {"p": client_name}).fetchall()
        return [{"name": r[0], "id": r[1]} for r in rows]

def get_products_by_family(family_name):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT entity_value, row_id
            FROM public.aira_hierarchy
            WHERE entity_type = 'Product' AND parent = :p
            ORDER BY entity_value
        """), {"p": family_name}).fetchall()
        return [{"name": r[0], "id": r[1]} for r in rows]

# -------------------------
# Page: manage hierarchy
# -------------------------
@router.get("/manage-hierarchy", response_class=HTMLResponse)
def manage_hierarchy(
    request: Request,
    message: str = Query(default=None),
    status: str = Query(default=None)
):
    clients = get_clients()
    with engine.connect() as conn:
        families = conn.execute(text("""
            SELECT row_id, parent, entity_value
            FROM public.aira_hierarchy
            WHERE entity_type='ProductFamily'
            ORDER BY parent, entity_value
        """)).fetchall()
        products = conn.execute(text("""
            SELECT row_id, parent, entity_value
            FROM public.aira_hierarchy
            WHERE entity_type='Product'
            ORDER BY parent, entity_value
        """)).fetchall()
    return templates.TemplateResponse("manage_clients2.html", {
        "request": request,
        "clients": clients,
        "families": families,
        "products": products,
        "message": message,
        "status": status
    })

# -------------------------
# Add Client
# -------------------------
@router.post("/add-client")
def add_client(name: str = Form(...)):
    try:
        with engine.connect() as conn:
            exists = conn.execute(text("""
                SELECT 1 FROM public.aira_hierarchy
                WHERE entity_type = 'Client' AND entity_value = :v
            """), {"v": name}).fetchone()
            if exists:
                return RedirectResponse(
                    url=f"/manage-hierarchy?message=Client '{name}' already exists. Please try a different name.&status=error",
                    status_code=303
                )
        sync_row_id_sequence()
        with engine.begin() as conn:
            conn.execute(text("""
                INSERT INTO public.aira_hierarchy(parent, entity_type, entity_value)
                VALUES (:p, 'Client', :v)
            """), {"p": name, "v": name})
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Client '{name}' added successfully!&status=success",
            status_code=303
        )
    except SQLAlchemyError as e:
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Error adding client: {str(e)}&status=error",
            status_code=303
        )

# -------------------------
# Edit Client
# -------------------------
@router.post("/edit-client/{row_id}")
def edit_client(row_id: int, name: str = Form(...)):
    try:
        with engine.begin() as conn:
            old = conn.execute(text("""
                SELECT entity_value FROM public.aira_hierarchy
                WHERE row_id = :id
            """), {"id": row_id}).scalar()
            conn.execute(text("""
                UPDATE public.aira_hierarchy
                SET entity_value = :v
                WHERE row_id = :id
            """), {"v": name, "id": row_id})
            conn.execute(text("""
                UPDATE public.aira_hierarchy
                SET parent = :new
                WHERE parent = :old AND entity_type = 'ProductFamily'
            """), {"new": name, "old": old})
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Client updated successfully!&status=success",
            status_code=303
        )
    except SQLAlchemyError as e:
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Error updating client: {str(e)}&status=error",
            status_code=303
        )

# -------------------------
# Delete Client
# -------------------------
@router.get("/delete-client/{row_id}")
def delete_client(row_id: int):
    try:
        with engine.begin() as conn:
            client_value = conn.execute(text("""
                SELECT entity_value FROM public.aira_hierarchy
                WHERE row_id = :id
            """), {"id": row_id}).scalar()
            conn.execute(text("""
                DELETE FROM public.aira_hierarchy
                WHERE entity_type = 'Product'
                  AND parent IN (
                      SELECT entity_value FROM public.aira_hierarchy
                      WHERE entity_type='ProductFamily' AND parent = :client_val
                  )
            """), {"client_val": client_value})
            conn.execute(text("""
                DELETE FROM public.aira_hierarchy
                WHERE entity_type='ProductFamily' AND parent = :client_val
            """), {"client_val": client_value})
            conn.execute(text("""
                DELETE FROM public.aira_hierarchy WHERE row_id = :id
            """), {"id": row_id})
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Client deleted successfully!&status=success",
            status_code=303
        )
    except SQLAlchemyError as e:
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Error deleting client: {str(e)}&status=error",
            status_code=303
        )

# -------------------------
# Add Product Family
# -------------------------
@router.post("/add-family")
def add_family(client: str = Form(...), family_name: str = Form(...)):
    try:
        with engine.connect() as conn:
            exists = conn.execute(text("""
                SELECT 1 FROM public.aira_hierarchy
                WHERE entity_type = 'ProductFamily' AND entity_value = :v AND parent = :p
            """), {"v": family_name, "p": client}).fetchone()
            if exists:
                return RedirectResponse(
                    url=f"/manage-hierarchy?message=Product Family '{family_name}' already exists for Client '{client}'.&status=error",
                    status_code=303
                )
        sync_row_id_sequence()
        with engine.begin() as conn:
            conn.execute(text("""
                INSERT INTO public.aira_hierarchy(parent, entity_type, entity_value)
                VALUES (:p, 'ProductFamily', :v)
            """), {"p": client, "v": family_name})
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Product Family '{family_name}' added successfully under Client '{client}'!&status=success",
            status_code=303
        )
    except SQLAlchemyError as e:
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Error adding product family: {str(e)}&status=error",
            status_code=303
        )

# -------------------------
# Edit Product Family
# -------------------------
@router.post("/edit-family/{row_id}")
def edit_family(row_id: int, family_name: str = Form(...), client: str = Form(...)):
    try:
        with engine.begin() as conn:
            old = conn.execute(text("""
                SELECT entity_value FROM public.aira_hierarchy
                WHERE row_id = :id
            """), {"id": row_id}).scalar()
            conn.execute(text("""
                UPDATE public.aira_hierarchy
                SET entity_value = :v, parent = :p
                WHERE row_id = :id
            """), {"v": family_name, "p": client, "id": row_id})
            conn.execute(text("""
                UPDATE public.aira_hierarchy
                SET parent = :new
                WHERE parent = :old AND entity_type = 'Product'
            """), {"new": family_name, "old": old})
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Product Family updated successfully!&status=success",
            status_code=303
        )
    except SQLAlchemyError as e:
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Error updating product family: {str(e)}&status=error",
            status_code=303
        )

# -------------------------
# Delete Product Family
# -------------------------
@router.get("/delete-family/{row_id}")
def delete_family(row_id: int):
    try:
        with engine.begin() as conn:
            family_value = conn.execute(text("""
                SELECT entity_value FROM public.aira_hierarchy
                WHERE row_id = :id
            """), {"id": row_id}).scalar()
            conn.execute(text("""
                DELETE FROM public.aira_hierarchy
                WHERE entity_type='Product' AND parent = :family_val
            """), {"family_val": family_value})
            conn.execute(text("""
                DELETE FROM public.aira_hierarchy WHERE row_id = :id
            """), {"id": row_id})
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Product Family deleted successfully!&status=success",
            status_code=303
        )
    except SQLAlchemyError as e:
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Error deleting product family: {str(e)}&status=error",
            status_code=303
        )

# -------------------------
# Add Product
# -------------------------
@router.post("/add-product")
def add_product(family: str = Form(...), product_name: str = Form(...)):
    try:
        with engine.connect() as conn:
            exists = conn.execute(text("""
                SELECT 1 FROM public.aira_hierarchy
                WHERE entity_type = 'Product' AND entity_value = :v AND parent = :p
            """), {"v": product_name, "p": family}).fetchone()
            if exists:
                return RedirectResponse(
                    url=f"/manage-hierarchy?message=Product '{product_name}' already exists for Family '{family}'.&status=error",
                    status_code=303
                )
        sync_row_id_sequence()
        with engine.begin() as conn:
            conn.execute(text("""
                INSERT INTO public.aira_hierarchy(parent, entity_type, entity_value)
                VALUES (:p, 'Product', :v)
            """), {"p": family, "v": product_name})
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Product '{product_name}' added successfully under Family '{family}'!&status=success",
            status_code=303
        )
    except SQLAlchemyError as e:
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Error adding product: {str(e)}&status=error",
            status_code=303
        )

# -------------------------
# Edit Product
# -------------------------
@router.post("/edit-product/{row_id}")
def edit_product(row_id: int, product_name: str = Form(...), family: str = Form(...)):
    try:
        with engine.begin() as conn:
            conn.execute(text("""
                UPDATE public.aira_hierarchy
                SET entity_value = :v, parent = :p
                WHERE row_id = :id
            """), {"v": product_name, "p": family, "id": row_id})
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Product updated successfully!&status=success",
            status_code=303
        )
    except SQLAlchemyError as e:
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Error updating product: {str(e)}&status=error",
            status_code=303
        )

# -------------------------
# Delete Product
# -------------------------
@router.get("/delete-product/{row_id}")
def delete_product(row_id: int):
    try:
        with engine.begin() as conn:
            conn.execute(text("""
                DELETE FROM public.aira_hierarchy WHERE row_id = :id
            """), {"id": row_id})
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Product deleted successfully!&status=success",
            status_code=303
        )
    except SQLAlchemyError as e:
        return RedirectResponse(
            url=f"/manage-hierarchy?message=Error deleting product: {str(e)}&status=error",
            status_code=303
        )

# -------------------------
# APIs for cascading dropdowns
# -------------------------
@router.get("/api/families/{client}", response_class=JSONResponse)
def api_families(client: str):
    return JSONResponse(get_families_by_client(client))

@router.get("/api/products/{family}", response_class=JSONResponse)
def api_products(family: str):
    return JSONResponse(get_products_by_family(family))
