from fastapi import FastAPI, Request, Form, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text
from fastapi import APIRouter, Query
from starlette.status import HTTP_303_SEE_OTHER
import os
import pandas as pd

router=APIRouter()
templates = Jinja2Templates(directory="templates")

# DB config
DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")

DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL)

@router.get("/upload", response_class=HTMLResponse)
def get_upload_page(request: Request, message: str = None):
    return templates.TemplateResponse("aliasname_store.html", {"request": request, "message": message})

@router.post("/upload-alias")
async def upload_alias(
    request: Request,
    aliasname: str = Form(None),
    document: UploadFile = File(None)
):
    msg = ""
    status = "success"

    try:
        with engine.begin() as conn:
            inserted_count = 0

            # Insert single alias (if provided)
            if aliasname:
                alias = aliasname.strip()
                exists = conn.execute(text("SELECT 1 FROM aliases WHERE aliasname = :aliasname"), {"aliasname": alias}).scalar()
                if not exists:
                    conn.execute(text("""
                        INSERT INTO aliases(aliasname, isactive, isassigned)
                        VALUES (:aliasname, TRUE, FALSE)
                    """), {"aliasname": alias})
                    inserted_count += 1

            # Insert multiple aliases from Excel (if file provided)
            if document:
                contents = await document.read()
                df = pd.read_excel(contents)

                alias_col = df.columns[0]
                aliases = df[alias_col].dropna().unique()

                for alias in aliases:
                    alias = str(alias).strip()
                    exists = conn.execute(text("SELECT 1 FROM aliases WHERE aliasname = :aliasname"), {"aliasname": alias}).scalar()
                    if not exists:
                        conn.execute(text("""
                            INSERT INTO aliases(aliasname, isactive, isassigned)
                            VALUES (:aliasname, TRUE, FALSE)
                        """), {"aliasname": alias})
                        inserted_count += 1

            if inserted_count == 0:
                msg = "No new alias names added (all duplicates or empty input)."
                status = "error"
            else:
                msg = f"Successfully added {inserted_count} alias name(s)."

    except Exception as e:
        msg = f"Error processing upload: {str(e)}"
        status = "error"

    from urllib.parse import quote_plus
    redirect_url = f"/upload?message={quote_plus(msg)}&status={status}"
    return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)
