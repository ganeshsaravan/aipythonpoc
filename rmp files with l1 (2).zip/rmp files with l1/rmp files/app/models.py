from sqlalchemy import create_engine, Table, Column, String, Integer, Date, MetaData
from sqlalchemy.orm import declarative_base, sessionmaker
import os

# Database configuration
# DB_USER = "baxterdev"
# DB_PASSWORD = "Password%40123%21"
# DB_HOST = "localhost"
# DB_PORT = "5432"
# DB_NAME = "baxterdb"
DB_USER = os.getenv("DB_USER","baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD","Password123")  # should be URL-encoded
DB_HOST = os.getenv("DB_HOST","db")
DB_PORT = os.getenv("DB_PORT","5432")
DB_NAME = os.getenv("DB_NAME","baxterdb")

#print(f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
# SQLAlchemy setup
engine = create_engine(f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}")
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()
metadata = MetaData()

# Define tables using SQLAlchemy Core

submissions = Table(
    "submissions",
    metadata,
    Column("id", String, primary_key=True),
    Column("filename", String),
    Column("filepath", String),
    Column("folder", String),
    Column("status", String),
    Column("approval_level", Integer, default=1),
    Column("max_approval_level", Integer, default=2),
    Column("sender_email", String),
    Column("sender_password", String),
    Column("approver_email", String),
)

users = Table(
    "users",
    metadata,
    Column("username", String, primary_key=True),
    Column("password", String, nullable=False),
    Column("gmail", String, nullable=False),
    Column("gmail_password", String, nullable=False),
    Column("app_password", String, nullable=False),
    Column("dob", Date, nullable=False),
)

product_files = Table(
    "product_files",
    metadata,
    Column("id", String, primary_key=True),
    Column("folder_name", String),
    Column("file_name", String),
    Column("file_path", String),
)

# Create the tables in the database
if __name__ == "__main__":
    metadata.create_all(engine)
    print("✅ Tables created using SQLAlchemy Core.")
