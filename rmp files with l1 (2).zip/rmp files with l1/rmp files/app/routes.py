from fastapi import APIRouter, Request, Form, UploadFile, File
from fastapi.responses import RedirectResponse, FileResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select, insert, update
from models import engine, submissions, users  # SQLAlchemy Core tables
from email_utils import send_approval_email, notify_sender
import os
import shutil
import uuid
from datetime import datetime
from product_folderview import router as product_router
from uploadfiles import save_files_to_folder
from typing import List


UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

router = APIRouter()
templates = Jinja2Templates(directory="templates")

DEFAULT_APPROVERS = ["ganesh000030@gmail.com", "ganeshsaravanakanisetty@gmail.com"]

def get_logged_in_username(request: Request):
    return request.cookies.get("username", "")

@router.get("/")
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "username": get_logged_in_username(request)})

@router.get("/home")
def homeindex(request: Request):
    return templates.TemplateResponse("home.html", {"request": request, "username": get_logged_in_username(request)})

@router.get("/chatbot")
def chatbot(request: Request):
    return templates.TemplateResponse("chatbot.html", {"request": request, "username": get_logged_in_username(request)})

@router.get("/register")
def register_get(request: Request):
    return templates.TemplateResponse("register.html", {"request": request, "error": None})

@router.post("/register")
def register_post(request: Request, username: str = Form(...), password: str = Form(...),
                  gmail: str = Form(...), gmail_password: str = Form(...),
                  app_password: str = Form(...), dob: str = Form(...)):
    with engine.connect() as conn:
        if conn.execute(select(users).where(users.c.username == username)).first():
            return templates.TemplateResponse("register.html", {"request": request, "error": "Username already exists"})
        if conn.execute(select(users).where(users.c.gmail == gmail)).first():
            return templates.TemplateResponse("register.html", {"request": request, "error": "Email already exists"})

    with engine.begin() as conn:
        conn.execute(insert(users).values(
            username=username,
            password=password,
            gmail=gmail,
            gmail_password=gmail_password,
            app_password=app_password,
            dob=datetime.strptime(dob, "%Y-%m-%d").date()
        ))
    return RedirectResponse("/login", status_code=303)

@router.get("/login")
def login_get(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})

@router.post("/login")
def login_post(request: Request, username: str = Form(...), password: str = Form(...)):
    with engine.connect() as conn:
        user = conn.execute(select(users).where(users.c.username == username, users.c.password == password)).first()
        if user:
            response = RedirectResponse("/home", status_code=303)
            response.set_cookie(key="username", value=username)
            return response
        elif username == "approver" and password == "approver123":
            response = RedirectResponse("/approve", status_code=303)
            response.set_cookie(key="username", value="approver")
            return response
    return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid credentials"})

@router.get("/logout")
def logout(request: Request):
    response = RedirectResponse("/", status_code=303)
    response.delete_cookie("username")
    return response

@router.get("/sender")
def sender_get(request: Request):
    username = get_logged_in_username(request)
    with engine.connect() as conn:
        subs = conn.execute(select(submissions)).fetchall()
        user = conn.execute(select(users).where(users.c.username == username)).first()
    return templates.TemplateResponse("sender.html", {
        "request": request,
        "submissions": subs,
        "user": user,
        "username": username,
        "message": request.query_params.get("message")
    })

@router.post("/sender")
async def upload_file(request: Request, file: UploadFile = File(...), folder: str = Form(...)):
    username = get_logged_in_username(request)

    # Fetch user details
    with engine.connect() as conn:
        user = conn.execute(select(users).where(users.c.username == username)).first()

    submission_id = str(uuid.uuid4())
    folder_path = os.path.join(UPLOAD_DIR, folder)
    os.makedirs(folder_path, exist_ok=True)
    filepath = os.path.join(folder_path, f"{submission_id}_{file.filename}")

    # Save the uploaded file
    with open(filepath, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Insert submission record into DB
    with engine.begin() as conn:
        conn.execute(insert(submissions).values(
            id=submission_id,
            filename=file.filename,
            filepath=filepath,
            folder=folder,
            status="Level 1 Approval Pending",
            sender_email=user.gmail,
            sender_password=user.app_password,
            approver_email=DEFAULT_APPROVERS[0],
            approval_level=1,
            max_approval_level=len(DEFAULT_APPROVERS)
        ))

    # 🔍 Fetch the inserted row to pass as a Row object (not dict) to send_approval_email
    with engine.connect() as conn:
        submission = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()

    # ✅ Now pass the actual Row to the email function
    send_approval_email(submission)

    return RedirectResponse("/sender?message=File submitted successfully", status_code=303)


@router.get("/approve")
def approve_get(request: Request):
    username = get_logged_in_username(request)
    with engine.connect() as conn:
        pending = conn.execute(select(submissions).where(submissions.c.status.like("Level%Pending"))).fetchall()
    return templates.TemplateResponse("approve.html", {"request": request, "pending": pending, "username": username})

@router.post("/approve")
def submit_decision(submission_id: str = Form(...), action: str = Form(...)):
    with engine.begin() as conn:
        sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
        if not sub:
            return RedirectResponse("/approve", status_code=303)

        if action == "approve":
            if sub.approval_level < sub.max_approval_level:
                new_level = sub.approval_level + 1
                conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                    approval_level=new_level,
                    status=f"Level {new_level} Approval Pending",
                    approver_email=DEFAULT_APPROVERS[new_level - 1]
                ))

                # Fetch the updated row
                updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
                send_approval_email(updated_sub)

            else:
                conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                    status="Approved"
                ))

                updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
                notify_sender(updated_sub)
        else:
            conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                status="Referred Back"
            ))

            updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
            notify_sender(updated_sub)

    return RedirectResponse("/approve", status_code=303)

@router.get("/email/decision/{submission_id}/{action}")
def email_decision(submission_id: str, action: str):
    with engine.begin() as conn:
        sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
        if not sub or not sub.status.startswith("Level") or "Pending" not in sub.status:
            return HTMLResponse("Invalid submission", status_code=400)

        if action == "approve":
            if sub.approval_level < sub.max_approval_level:
                new_level = sub.approval_level + 1
                conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                    approval_level=new_level,
                    status=f"Level {new_level} Approval Pending",
                    approver_email=DEFAULT_APPROVERS[new_level - 1]
                ))

                updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
                send_approval_email(updated_sub)

            else:
                conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                    status="Approved"
                ))

                updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
                notify_sender(updated_sub)
        else:
            conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                status="Referred Back"
            ))

            updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
            notify_sender(updated_sub)

    return HTMLResponse(f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Decision Recorded</title>
            <script>
                alert("The file '{sub.filename}' has been {action}d.");
                window.close();
            </script>
        </head>
        <body>
            <p>If this tab doesn't close automatically, you can close it manually.</p>
        </body>
        </html>
    """)

@router.get("/download/{submission_id}")
def download_file(submission_id: str):
    with engine.connect() as conn:
        sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
    if sub:
        return FileResponse(sub.filepath, filename=sub.filename)
    return {"error": "File not found"}

@router.get("/folder")
def folder(request: Request):
    username = get_logged_in_username(request)
    with engine.connect() as conn:
        rows = conn.execute(select(submissions)).fetchall()
    folders = {}
    for sub in rows:
        key = sub.folder or "Uncategorized"
        folders.setdefault(key, []).append(sub)
    return templates.TemplateResponse("folder.html", {"request": request, "folders": folders, "username": username})

@router.get("/folderview")
def folderview_get(request: Request, folder: str = None):
    username = get_logged_in_username(request)
    with engine.connect() as conn:
        if folder:
            result = conn.execute(select(submissions).where(submissions.c.folder == folder)).fetchall()
            return templates.TemplateResponse(
                "folderview.html",
                {
                    "request": request,
                    "folder_name": folder,
                    "files": result,
                    "username": username
                }
            )
        else:
            # fallback if no folder specified
            return RedirectResponse("/folder", status_code=303)

@router.get("/approvestatus/{submission_id}")
def approval_status(submission_id: str, request: Request):
    with engine.connect() as conn:
        sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()

    if not sub:
        return HTMLResponse("Submission not found", status_code=404)

    status = sub.status

    if status == "Approved":
        level1_status = "Approved"
        level2_status = "Approved"
    elif status == "Referred Back":
        # We assume if it was referred back, it could be either level
        if sub.approval_level == 1:
            level1_status = "Referred Back"
            level2_status = "Pending"
        else:
            level1_status = "Approved"
            level2_status = "Referred Back"
    elif "Level 1" in status:
        level1_status = "Pending"
        level2_status = "Pending"
    elif "Level 2" in status:
        level1_status = "Approved"
        level2_status = "Pending"
    else:
        level1_status = "Pending"
        level2_status = "Pending"

    return templates.TemplateResponse("approvestatus.html", {
    "request": request,
    "submission": sub,
    "username": get_logged_in_username(request),
    "level1_status": level1_status,
    "level2_status": level2_status,
    "approver2_email": DEFAULT_APPROVERS[1] if len(DEFAULT_APPROVERS) > 1 else ""
})

@router.get("/upload")
def upload_page(request: Request, message: str = "", error: str = ""):
    username = get_logged_in_username(request)
    return templates.TemplateResponse("uploadfiles.html", {
        "request": request,
        "message": message,
        "error": error,
        "username": username
    })


@router.post("/upload")
async def upload_files_to_folder(
    request: Request,
    folder: str = Form(...),
    files: List[UploadFile] = File(...)
):
    username = get_logged_in_username(request)
    try:
        count = save_files_to_folder(files, folder)
        return templates.TemplateResponse("uploadfiles.html", {
            "request": request,
            "message": f"{count} file(s) uploaded successfully to folder '{folder}'",
            "error": "",
            "username": username
        })
    except Exception as e:
        return templates.TemplateResponse("uploadfiles.html", {
            "request": request,
            "message": "",
            "error": f"Upload failed: {str(e)}",
            "username": username
        })


def include_routes(app):
    app.include_router(router)
    app.include_router(product_router)