from fastapi import APIRouter, Request, Form, Query, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, MetaData, Table, select, text
import os
from datetime import datetime
from starlette.status import HTTP_303_SEE_OTHER

router = APIRouter()
templates = Jinja2Templates(directory="templates")

DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

engine = create_engine(DATABASE_URL)
metadata = MetaData()

# Reflect the existing prompts table
metadata.reflect(bind=engine)
prompts = metadata.tables.get("prompts")
if prompts is None:
    raise Exception("Table 'prompts' not found in database")

@router.get("/")
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@router.get("/new")
def home(request: Request):
    return templates.TemplateResponse("new.html", {"request": request})


@router.get("/prompts", response_class=HTMLResponse)
async def prompt_tabs(
    request: Request,
    client: str = Query(default=""),
    product_family: str = Query(default=""),
    product: str = Query(default=""),
    message: str = Query(default="")
):
    with engine.connect() as conn:
        clients = [row[0] for row in conn.execute(
            text("SELECT entity_value FROM public.aira_hierarchy WHERE entity_type = 'Client'")
        ).fetchall()]

        product_families = []
        if client:
            product_families = [row[0] for row in conn.execute(
                text("""
                    SELECT entity_value FROM public.aira_hierarchy 
                    WHERE parent = :client AND entity_type = 'ProductFamily'
                """), {"client": client}
            ).fetchall()]

        products = []
        if product_family:
            products = [row[0] for row in conn.execute(
                text("""
                    SELECT entity_value FROM public.aira_hierarchy 
                    WHERE parent = :pf AND entity_type = 'Product'
                """), {"pf": product_family}
            ).fetchall()]

        query = select(prompts)
        if client:
            query = query.where(prompts.c.client == client)
        if product_family:
            query = query.where(prompts.c.product_family == product_family)
        if product:
            query = query.where(prompts.c.product == product)

        result = conn.execute(query).fetchall()
        prompts_list = [dict(row._mapping) for row in result]


    return templates.TemplateResponse("prompt_tabs.html", {
        "request": request,
        "clients": clients,
        "product_families": product_families,
        "products": products,
        "prompts": prompts_list,
        "selected_client": client,
        "selected_product_family": product_family,
        "selected_product": product,
        "message":message
    })

@router.get("/create", response_class=HTMLResponse)
async def create_prompt_form(request: Request):
    with engine.connect() as conn:
        result = conn.execute(text("""
            SELECT entity_value 
            FROM public.aira_hierarchy 
            WHERE entity_type = 'Client'
        """)).fetchall()
        clients = [row[0] for row in result]

    return templates.TemplateResponse("create_prompt3.html",
        {"request": request,
         "clients": clients}
    )

@router.get("/get_product_families/{client}")
async def get_product_families(client: str):
    with engine.connect() as conn:
        result = conn.execute(text("""
            SELECT entity_value 
            FROM public.aira_hierarchy 
            WHERE parent = :client 
            AND entity_type = 'ProductFamily'
        """), {"client": client}).fetchall()
        return JSONResponse([row[0] for row in result])

@router.get("/get_aliases")
async def get_aliases():
    with engine.connect() as conn:
        result = conn.execute(text("SELECT aliasname FROM public.aliases")).fetchall()
        return JSONResponse([row[0] for row in result])
    
@router.get("/get_product/{product_family}")
async def get_products(product_family: str):
    with engine.connect() as conn:
        result = conn.execute(text("""
            SELECT entity_value 
            FROM public.aira_hierarchy 
            WHERE parent = :pf 
            AND entity_type = 'Product'
        """), {"pf": product_family}).fetchall()
        return JSONResponse([row[0] for row in result])


@router.get("/get_templates")
async def get_templates():
    with engine.connect() as conn:
        result = conn.execute(text("""
            SELECT templatename 
            FROM public.template
        """)).fetchall()
        return JSONResponse([row[0] for row in result])

@router.post("/save-prompt")
def save_prompt(
    request: Request,
    client: str = Form(...),
    product_family: str = Form(...),
    product: str = Form(...),
    template: str = Form(...),
    document_alias: str = Form(...),
    prompt_name: str = Form(...),
    prompt_text: str = Form(...),
):
    insert_query = text("""
        INSERT INTO prompts 
        (client, product_family, product, document_alias_name, prompt_name, prompt_text, created_on,template_name)
        VALUES 
        (:client, :product_family, :product, :document_alias, :prompt_name, :prompt_text, :created_on,:template)
    """)
    with engine.connect() as conn:
        conn.execute(insert_query, {
            "client": client,
            "product_family": product_family,
            "product": product,
            "document_alias": document_alias,
            "prompt_name": prompt_name,
            "prompt_text": prompt_text,
            "created_on": datetime.utcnow(),
            "template": template,
        })
        conn.commit()

    # Redirect to /prompts with a message param, so prompts tab shows success message
    return RedirectResponse(url="/prompts?message=Prompt+saved+successfully", status_code=HTTP_303_SEE_OTHER)

@router.get("/view-prompts", response_class=HTMLResponse)
async def view_prompts(
    request: Request,
    client: str = Query(default=""),
    product_family: str = Query(default=""),
    product: str = Query(default="")
):
    with engine.connect() as conn:
        # Fetch all clients for dropdown
        clients = [row[0] for row in conn.execute(
            text("SELECT entity_value FROM public.aira_hierarchy WHERE entity_type = 'Client'")
        ).fetchall()]

        # Build base query for prompts
        query_str = "SELECT * FROM prompts WHERE 1=1"
        params = {}

        if client:
            query_str += " AND client = :client"
            params["client"] = client

        if product_family:
            query_str += " AND product_family = :product_family"
            params["product_family"] = product_family

        if product:
            query_str += " AND product = :product"
            params["product"] = product

        query = text(query_str)
        prompts = conn.execute(query, params).fetchall()

    prompts_list = [dict(row._mapping) for row in prompts]

    return templates.TemplateResponse("view_prompts2.html", {
        "request": request,
        "clients": clients,
        "prompts": prompts_list,
        "selected_client": client,
        "selected_product_family": product_family,
        "selected_product": product,
    })



@router.get("/edit/{prompt_id}", response_class=HTMLResponse)
async def edit_prompt(request: Request, prompt_id: int):
    with engine.connect() as conn:
        prompt = conn.execute(
            text("SELECT * FROM prompts WHERE id = :id"), {"id": prompt_id}
        ).first()
        if not prompt:
            return HTMLResponse(content="❌ Prompt not found", status_code=404)

        clients = [row[0] for row in conn.execute(
            text("SELECT entity_value FROM public.aira_hierarchy WHERE entity_type = 'Client'")
        ).fetchall()]

        aliases = [row[0] for row in conn.execute(
            text("SELECT aliasname FROM public.aliases")
        ).fetchall()]

        prompt_dict = dict(prompt._mapping)

    return templates.TemplateResponse("edit_prompt.html", {
        "request": request,
        "prompt": prompt_dict,
        "clients": clients,
        "aliases": aliases,
        "message": None
    })

@router.post("/update/{prompt_id}", response_class=HTMLResponse)
async def update_prompt(
    request: Request,
    prompt_id: int,
    client: str = Form(...),
    product_family: str = Form(...),
    product: str = Form(...),
    document_alias_name: str = Form(...),
    prompt_name: str = Form(...),
    prompt_text: str = Form(...)
):
    with engine.begin() as conn:
        query = prompts.update().where(prompts.c.id == prompt_id).values(
            client=client,
            product_family=product_family,
            product=product,
            document_alias_name=document_alias_name,
            prompt_name=prompt_name,
            prompt_text=prompt_text
        )
        conn.execute(query)
    
    return RedirectResponse(url="/prompts?message=Prompt+updated+successfully", status_code=HTTP_303_SEE_OTHER)

@router.get("/delete/{prompt_id}")
async def delete_prompt(prompt_id: int):
    with engine.begin() as conn:
        query = prompts.delete().where(prompts.c.id == prompt_id)
        conn.execute(query)

    return RedirectResponse(url="/prompts?message=Prompt+updated+successfully", status_code=HTTP_303_SEE_OTHER)
