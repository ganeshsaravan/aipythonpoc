from fastapi import APIRouter, Request, Form, Query
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text, MetaData
from starlette.status import HTTP_303_SEE_OTHER
import os
from urllib.parse import quote_plus

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# DB config
DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

engine = create_engine(DATABASE_URL)
metadata = MetaData()


def sync_row_id_sequence():
    with engine.begin() as conn:
        conn.execute(text("""
            SELECT setval(
                pg_get_serial_sequence('public.aira_hierarchy', 'row_id'),
                COALESCE((SELECT MAX(row_id) FROM public.aira_hierarchy), 0) + 1,
                false
            );
        """))


def get_clients():
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT entity_value, row_id
            FROM public.aira_hierarchy
            WHERE entity_type = 'Client'
            ORDER BY entity_value
        """)).fetchall()
        return [{"name": r[0], "id": r[1]} for r in rows]


def get_families_by_client(client_name):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT entity_value, row_id
            FROM public.aira_hierarchy
            WHERE entity_type = 'ProductFamily' AND parent = :p
            ORDER BY entity_value
        """), {"p": client_name}).fetchall()
        return [{"name": r[0], "id": r[1]} for r in rows]


def get_products_by_family(family_name):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT entity_value, row_id
            FROM public.aira_hierarchy
            WHERE entity_type = 'Product' AND parent = :p
            ORDER BY entity_value
        """), {"p": family_name}).fetchall()
        return [{"name": r[0], "id": r[1]} for r in rows]


# -------------------------
# Page: manage hierarchy with optional messages from query params
# -------------------------
@router.get("/manage-hierarchy", response_class=HTMLResponse)
def manage_hierarchy(request: Request, message: str = Query(None), status: str = Query(None)):
    clients = get_clients()
    return templates.TemplateResponse("manage_clients3.html", {
        "request": request,
        "clients": clients,
        "message": message,
        "status": status
    })


# -------------------------
# Add Client
# -------------------------
@router.post("/add-client")
def add_client(name: str = Form(...)):
    try:
        sync_row_id_sequence()
        with engine.begin() as conn:
            conn.execute(text("""
                INSERT INTO public.aira_hierarchy(parent, entity_type, entity_value)
                VALUES (:p, 'Client', :v)
            """), {"p": name, "v": name})
        msg = "Client added successfully."
        stat = "success"
    except Exception as e:
        msg = f"Error adding client: {str(e)}"
        stat = "error"

    redirect_url = f"/manage-hierarchy?message={quote_plus(msg)}&status={stat}"
    return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)


# -------------------------
# Edit Client
# -------------------------
@router.post("/edit-client/{row_id}")
def edit_client(row_id: int, name: str = Form(...)):
    try:
        with engine.begin() as conn:
            old = conn.execute(text("""
                SELECT entity_value
                FROM public.aira_hierarchy
                WHERE row_id = :id
            """), {"id": row_id}).scalar()
            conn.execute(text("""
                UPDATE public.aira_hierarchy
                SET entity_value = :v
                WHERE row_id = :id
            """), {"v": name, "id": row_id})
            conn.execute(text("""
                UPDATE public.aira_hierarchy
                SET parent = :new
                WHERE parent = :old AND entity_type = 'ProductFamily'
            """), {"new": name, "old": old})
        msg = "Client updated successfully."
        stat = "success"
    except Exception as e:
        msg = f"Error updating client: {str(e)}"
        stat = "error"

    redirect_url = f"/manage-hierarchy?message={quote_plus(msg)}&status={stat}"
    return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)


# -------------------------
# Delete Client
# -------------------------
@router.get("/delete-client/{row_id}")
def delete_client(row_id: int):
    try:
        with engine.begin() as conn:
            client_value = conn.execute(text("""
                SELECT entity_value
                FROM public.aira_hierarchy
                WHERE row_id = :id
            """), {"id": row_id}).scalar()
            conn.execute(text("""
                DELETE FROM public.aira_hierarchy
                WHERE entity_type = 'Product'
                  AND parent IN (
                      SELECT entity_value
                      FROM public.aira_hierarchy
                      WHERE entity_type='ProductFamily' AND parent = :client_val
                  )
            """), {"client_val": client_value})
            conn.execute(text("""
                DELETE FROM public.aira_hierarchy
                WHERE entity_type='ProductFamily' AND parent = :client_val
            """), {"client_val": client_value})
            conn.execute(text("""
                DELETE FROM public.aira_hierarchy
                WHERE row_id = :id
            """), {"id": row_id})
        msg = "Client deleted successfully."
        stat = "success"
    except Exception as e:
        msg = f"Error deleting client: {str(e)}"
        stat = "error"

    redirect_url = f"/manage-hierarchy?message={quote_plus(msg)}&status={stat}"
    return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)


# -------------------------
# Add Product Family
# -------------------------
@router.post("/add-family")
def add_family(client: str = Form(...), family_name: str = Form(...)):
    try:
        sync_row_id_sequence()
        with engine.begin() as conn:
            conn.execute(text("""
                INSERT INTO public.aira_hierarchy(parent, entity_type, entity_value)
                VALUES (:p, 'ProductFamily', :v)
            """), {"p": client, "v": family_name})
        msg = "Product family added successfully."
        stat = "success"
    except Exception as e:
        msg = f"Error adding product family: {str(e)}"
        stat = "error"

    redirect_url = f"/manage-hierarchy?message={quote_plus(msg)}&status={stat}"
    return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)


# -------------------------
# Add Product
# -------------------------
@router.post("/add-product")
def add_product(family: str = Form(...), product_name: str = Form(...)):
    try:
        sync_row_id_sequence()
        with engine.begin() as conn:
            # Check if product already exists
            exists = conn.execute(text("""
                SELECT 1 FROM public.aira_hierarchy
                WHERE parent = :p AND entity_type = 'Product' AND entity_value = :v
            """), {"p": family, "v": product_name}).scalar()
            
            if exists:
                raise Exception(f"Product '{product_name}' already exists in family '{family}'.")
            
            conn.execute(text("""
                INSERT INTO public.aira_hierarchy(parent, entity_type, entity_value)
                VALUES (:p, 'Product', :v)
            """), {"p": family, "v": product_name})
        msg = "Product added successfully."
        stat = "success"
    except Exception as e:
        msg = f"Error adding product: {str(e)}"
        stat = "error"

    redirect_url = f"/manage-hierarchy?message={quote_plus(msg)}&status={stat}"
    return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)

# -------------------------
# API: Get families by client (JSON)
# -------------------------
@router.get("/api/families/{client}", response_class=JSONResponse)
def api_families(client: str):
    return JSONResponse(get_families_by_client(client))


# -------------------------
# API: Get products by family (JSON)
# -------------------------
@router.get("/api/products/{family}", response_class=JSONResponse)
def api_products(family: str):
    return JSONResponse(get_products_by_family(family))
