from fastapi import APIRouter, Request, Body, Form
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text
from typing import List, Dict, Any
import os
from datetime import datetime

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# DB connection
DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL)


# === PAGES ===
@router.get("/template-mapping", response_class=HTMLResponse)
def template_source_mapping_page(request: Request):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT DISTINCT client
            FROM template
            WHERE client IS NOT NULL AND client <> ''
            ORDER BY client
        """)).fetchall()
    return templates.TemplateResponse("template_mapping.html", {"request": request, "clients": [r[0] for r in rows]})


# === API: Cascading Dropdowns ===
@router.get("/api/product-families/{client}")
def get_product_families(client: str):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT DISTINCT productfamily
            FROM template
            WHERE client = :client
              AND productfamily IS NOT NULL AND productfamily <> ''
            ORDER BY productfamily
        """), {"client": client}).fetchall()
    return JSONResponse({"families": [r[0] for r in rows]})


@router.get("/api/products/{client}/{family}")
def get_products(client: str, family: str):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT DISTINCT product
            FROM template
            WHERE client = :client
              AND productfamily = :family
              AND product IS NOT NULL AND product <> ''
            ORDER BY product
        """), {"client": client, "family": family}).fetchall()
    return JSONResponse({"products": [r[0] for r in rows]})


@router.get("/api/templates/{client}/{family}/{product}")
def get_templates(client: str, family: str, product: str):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT DISTINCT templatename
            FROM template
            WHERE client = :client
              AND productfamily = :family
              AND product = :product
              AND isactive = TRUE
              AND templatename IS NOT NULL AND templatename <> ''
            ORDER BY templatename
        """), {"client": client, "family": family, "product": product}).fetchall()
    return JSONResponse({"templates": [r[0] for r in rows]})


@router.get("/api/file-options")
def get_file_options():
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT originalfilename, alias
            FROM file_uploads
            ORDER BY originalfilename
        """)).fetchall()

    def mk(row):
        orig, alias = row
        return {"display": f"{orig} | {alias}", "alias": alias}

    pdf = [mk(r) for r in rows if r[0].lower().endswith(".pdf")]
    excel = [mk(r) for r in rows if r[0].lower().endswith((".xlsx", ".xls", ".csv"))]

    return JSONResponse({"pdfOptions": pdf, "excelOptions": excel, "urlOptions": []})


# === API: Load Mappings Table ===
@router.get("/api/mappings")
def get_mappings(page: int = 1, limit: int = 10):
    offset = (page - 1) * limit
    with engine.connect() as conn:
        total_query = conn.execute(text("SELECT COUNT(*) FROM templatesource_map"))
        total = total_query.scalar()

        query = conn.execute(text("""
            SELECT id, client, productfamily, product, templatename, aliasname, sourcetype, createdon
            FROM templatesource_map
            ORDER BY id
            LIMIT :limit OFFSET :offset
        """), {"limit": limit, "offset": offset})
        rows = query.fetchall()

    data = [
        {
            "id": r[0],
            "client": r[1],
            "productfamily": r[2],
            "product": r[3],
            "templatename": r[4],
            "aliasname": r[5],
            "sourcetype": r[6],
            "createdon": r[7].isoformat() if r[7] else None
        }
        for r in rows
    ]

    return JSONResponse({
        "data": data,
        "total": total,
        "page": page,
        "limit": limit,
        "pages": (total + limit - 1) // limit
    })


# === API: Save Mapping ===
@router.post("/api/save-mapping")
def save_mapping(payload: Dict[str, Any] = Body(...)):
    client = payload.get("client")
    family = payload.get("productFamily")
    product = payload.get("product")
    tname = payload.get("templatename")
    selections: List[Dict[str, str]] = payload.get("selections", [])

    if not all([client, family, product, tname]):
        return JSONResponse({"ok": False, "message": "Missing required fields"}, status_code=400)

    rows_to_insert = [
        {
            "client": client,
            "productfamily": family,
            "product": product,
            "templatename": tname,
            "aliasname": s["alias"],
            "sourcetype": s["sourcetype"],
            "createdon": datetime.utcnow()
        }
        for s in selections if s.get("alias")
    ]

    if not rows_to_insert:
        return JSONResponse({"ok": False, "message": "No selections"}, status_code=400)

    with engine.begin() as conn:
        conn.execute(text("""
            INSERT INTO templatesource_map
                (client, productfamily, product, templatename, aliasname, sourcetype, createdon)
            VALUES
                (:client, :productfamily, :product, :templatename, :aliasname, :sourcetype, :createdon)
        """), rows_to_insert)

    return JSONResponse({"ok": True, "message": "Mapping saved successfully"})


# === API: Delete Mapping (JSON-based, No Page Reload) ===
@router.post("/api/delete-mapping")
def api_delete_mapping(payload: dict = Body(...)):
    mappingid = payload.get("mappingid")
    if not mappingid:
        return JSONResponse({"ok": False, "message": "Missing mappingid"}, status_code=400)

    with engine.begin() as conn:
        result = conn.execute(text("""
            DELETE FROM templatesource_map
            WHERE id = :mappingid
        """), {"mappingid": mappingid})

    if result.rowcount == 0:
        return JSONResponse({"ok": False, "message": "No such mapping found"}, status_code=404)

    return JSONResponse({"ok": True, "message": "Deleted successfully"})
