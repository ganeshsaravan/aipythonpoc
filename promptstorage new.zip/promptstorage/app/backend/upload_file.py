from fastapi import APIRouter, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text
from fastapi import HTTPException
from starlette.status import HTTP_303_SEE_OTHER
import os
from urllib.parse import quote_plus

router = APIRouter()
templates = Jinja2Templates(directory="templates")

DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")

DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL)


# @router.get("/file-repository", response_class=HTMLResponse)
# def file_repo_get(request: Request, message: str = None):
#     with engine.connect() as conn:
#         clients = conn.execute(
#             text("SELECT entity_value FROM public.aira_hierarchy WHERE entity_type = 'Client' ORDER BY entity_value")
#         ).fetchall()
#         aliases = conn.execute(text("SELECT aliasname FROM aliases ORDER BY aliasname")).fetchall()

#     clients = [row[0] for row in clients]
#     aliases = [row[0] for row in aliases]

#     return templates.TemplateResponse("file_repository.html", {
#         "request": request,
#         "clients": clients,
#         "aliases": aliases,
#         "message": message
#     })



# @router.post("/upload-single")
# async def upload_single_pdf(
#     client: str = Form(...),
#     alias_name: str = Form(...),
#     uploaded_file: UploadFile = File(...)
# ):
#     try:
#         filename = uploaded_file.filename
#         ext = os.path.splitext(filename)[1].lower()  # e.g. '.pdf', '.xlsx', '.docx'

#         collection = f"{client}_{alias_name}"
#         save_dir = f"uploads/{collection}"
#         os.makedirs(save_dir, exist_ok=True)
#         save_path = os.path.join(save_dir, filename)

#         contents = await uploaded_file.read()
#         with open(save_path, "wb") as f:
#             f.write(contents)

#         with engine.begin() as conn:
#             conn.execute(text("""
#                 INSERT INTO file_uploads (Client, OriginalFileName, Alias, Extension, Collection)
#                 VALUES (:client, :filename, :alias, :ext, :collection)
#             """), {
#                 "client": client,
#                 "filename": filename,
#                 "alias": alias_name,
#                 "ext": ext,
#                 "collection": collection
#             })

#         msg = f"File '{filename}' uploaded successfully."
#         status = "success"
#     except Exception as e:
#         msg = f"Error: {str(e)}"
#         status = "error"

#     redirect_url = f"/file-repository?message={quote_plus(msg)}&status={status}"
#     return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)
@router.get("/file-repository", response_class=HTMLResponse)
def file_repo_get(request: Request, message: str = None):
    with engine.connect() as conn:
        clients = conn.execute(
            text("SELECT entity_value FROM public.aira_hierarchy WHERE entity_type = 'Client' ORDER BY entity_value")
        ).fetchall()
        aliases = conn.execute(
            text("SELECT aliasname FROM aliases WHERE isassigned = FALSE ORDER BY aliasname")
        ).fetchall()

    clients = [row[0] for row in clients]
    aliases = [row[0] for row in aliases]

    return templates.TemplateResponse("file_repository.html", {
        "request": request,
        "clients": clients,
        "aliases": aliases,
        "message": message
    })


@router.post("/upload-single")
async def upload_single_pdf(
    client: str = Form(...),
    alias_name: str = Form(...),
    uploaded_file: UploadFile = File(...)
):
    try:
        filename = uploaded_file.filename
        ext = os.path.splitext(filename)[1].lower()

        collection = f"{client}_{alias_name}"
        save_dir = f"uploads/{collection}"
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, filename)

        contents = await uploaded_file.read()
        with open(save_path, "wb") as f:
            f.write(contents)

        with engine.begin() as conn:
            conn.execute(text("""
                INSERT INTO file_uploads (Client, OriginalFileName, Alias, Extension, Collection)
                VALUES (:client, :filename, :alias, :ext, :collection)
            """), {
                "client": client,
                "filename": filename,
                "alias": alias_name,
                "ext": ext,
                "collection": collection
            })

            # Mark alias as assigned
            conn.execute(text("""
                UPDATE aliases SET isassigned = TRUE WHERE aliasname = :aliasname
            """), {"aliasname": alias_name})

        msg = f"File '{filename}' uploaded successfully."
        status = "success"
    except Exception as e:
        msg = f"Error: {str(e)}"
        status = "error"

    redirect_url = f"/file-repository?message={quote_plus(msg)}&status={status}"
    return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)

@router.get("/api/file-uploads")
def get_file_uploads():
    try:
        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT 
                    client,
                    originalfilename,
                    alias,
                    extension,
                    uploadedon,
                    collection
                FROM file_uploads
                ORDER BY uploadedon DESC
            """))
            rows = result.fetchall()

            data = []
            for row in rows:
                data.append({
                    "Client": row.client or "",
                    "OriginalFileName": row.originalfilename or "",
                    "Alias": row.alias or "",
                    "Extension": row.extension or "",
                    "UploadedOn": row.uploadedon.strftime("%Y-%m-%d %H:%M:%S") if row.uploadedon else "Unknown",
                    "Collection": row.collection or ""
                })

            return data

    except Exception as e:
        print(f"Error fetching file uploads: {e}")
        raise HTTPException(status_code=500, detail="Could not fetch file list")

from fastapi import Query  # Make sure this is imported

@router.post("/delete-file")
def delete_file(
    client: str = Form(...),
    alias: str = Form(...),
    filename: str = Form(...)
):
    try:
        collection = f"{client}_{alias}"
        file_path = f"uploads/{collection}/{filename}"

        # Delete file from disk
        if os.path.exists(file_path):
            os.remove(file_path)
            # Optionally remove the directory if empty
            dir_path = os.path.dirname(file_path)
            if os.path.isdir(dir_path) and not os.listdir(dir_path):
                os.rmdir(dir_path)
        else:
            raise FileNotFoundError("File not found on disk")

        # Delete from database
        with engine.begin() as conn:
            result = conn.execute(
                text("""
                DELETE FROM file_uploads 
                WHERE client = :client 
                  AND alias = :alias 
                  AND originalfilename = :filename
                """),
                {"client": client, "alias": alias, "filename": filename}
            )

            # If no row was deleted
            if result.rowcount == 0:
                msg = "File record not found in database."
                status = "error"
                redirect_url = f"/file-repository?message={quote_plus(msg)}&status={status}"
                return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)

            # Optional: unassign alias if no other file uses it
            remaining = conn.execute(
                text("SELECT COUNT(*) FROM file_uploads WHERE alias = :alias"),
                {"alias": alias}
            ).scalar()

            if remaining == 0:
                conn.execute(
                    text("UPDATE aliases SET isassigned = FALSE WHERE aliasname = :aliasname"),
                    {"aliasname": alias}
                )

        msg = f"File '{filename}' deleted successfully."
        status = "success"
    except FileNotFoundError:
        msg = f"File '{filename}' not found on server."
        status = "error"
    except Exception as e:
        msg = f"Error deleting file: {str(e)}"
        status = "error"

    redirect_url = f"/file-repository?message={quote_plus(msg)}&status={status}"
    return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)