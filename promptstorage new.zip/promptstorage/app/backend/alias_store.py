from fastapi import FastAPI, Request, Form, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text
from fastapi import APIRouter, Query
from starlette.status import HTTP_303_SEE_OTHER
import os
import pandas as pd

router=APIRouter()
templates = Jinja2Templates(directory="templates")

# DB config
DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")

DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL)

@router.get("/upload", response_class=HTMLResponse)
def get_upload_page(request: Request, message: str = None):
    return templates.TemplateResponse("aliasname_store1.html", {"request": request, "message": message})

@router.post("/upload-alias")
async def upload_alias(
    request: Request,
    aliasname: str = Form(None),
    document: UploadFile = File(None)
):
    msg = ""
    status = "success"

    try:
        with engine.begin() as conn:
            inserted_count = 0

            # Insert single alias (if provided)
            if aliasname:
                alias = aliasname.strip()
                exists = conn.execute(text("SELECT 1 FROM aliases WHERE aliasname = :aliasname"), {"aliasname": alias}).scalar()
                if not exists:
                    conn.execute(text("""
                        INSERT INTO aliases(aliasname, isactive, isassigned)
                        VALUES (:aliasname, TRUE, FALSE)
                    """), {"aliasname": alias})
                    inserted_count += 1

            # Insert multiple aliases from Excel (if file provided)
            if document:
                contents = await document.read()
                df = pd.read_excel(contents)

                alias_col = df.columns[0]
                aliases = df[alias_col].dropna().unique()

                for alias in aliases:
                    alias = str(alias).strip()
                    exists = conn.execute(text("SELECT 1 FROM aliases WHERE aliasname = :aliasname"), {"aliasname": alias}).scalar()
                    if not exists:
                        conn.execute(text("""
                            INSERT INTO aliases(aliasname, isactive, isassigned)
                            VALUES (:aliasname, TRUE, FALSE)
                        """), {"aliasname": alias})
                        inserted_count += 1

            if inserted_count == 0:
                msg = "No new alias names added (all duplicates or empty input)."
                status = "error"
            else:
                msg = f"Successfully added {inserted_count} alias name(s)."

    except Exception as e:
        msg = f"Error processing upload: {str(e)}"
        status = "error"

    from urllib.parse import quote_plus
    redirect_url = f"/upload?message={quote_plus(msg)}&status={status}"
    return RedirectResponse(url=redirect_url, status_code=HTTP_303_SEE_OTHER)

@router.get("/api/aliases")
def get_aliases(request: Request, tab: str = Query("0")):
    """
    Fetch all alias records from the database.
    Returns only the three existing fields: aliasname, isactive, isassigned.
    """
    try:
        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT 
                    aliasname, 
                    isactive, 
                    isassigned
                FROM aliases 
                ORDER BY aliasname
            """))
            rows = result.fetchall()

            # Convert rows to list of dicts
            data = []
            for row in rows:
                data.append({
                    "aliasname": row.aliasname,
                    "isactive": bool(row.isactive),
                    "isassigned": bool(row.isassigned)
                })

            return data

    except Exception as e:
        print(f"Error fetching aliases: {e}")
        return []
    
from fastapi import HTTPException
from typing import Dict
# -------------------------
# PUT: Edit an alias
# -------------------------
@router.put("/api/aliases/{old_aliasname}")
def edit_alias(old_aliasname: str, new_data: dict):
    new_name = new_data.get("aliasname", "").strip()

    print(f"--- Edit Request ---")
    print(f"Old: '{old_aliasname}', New: '{new_name}'")
    print(f"Request data: {new_data}")

    if not new_name:
        return {"error": "Alias name cannot be empty"}

    if new_name.lower() == old_aliasname.lower():
        return {"message": "No change detected"}

    try:
        with engine.begin() as conn:
            # Check if alias exists
            result = conn.execute(text("""
                SELECT isassigned FROM aliases WHERE aliasname = :old
            """), {"old": old_aliasname})
            row = result.fetchone()

            if not row:
                print(f"❌ Alias '{old_aliasname}' not found")
                return {"error": "Alias not found"}

            if row.isassigned:
                print(f"❌ Alias '{old_aliasname}' is assigned. Cannot edit.")
                return {"error": f"Cannot edit '{old_aliasname}' — it is assigned and locked."}

            # Check for duplicate
            exists = conn.execute(text("""
                SELECT 1 FROM aliases WHERE LOWER(aliasname) = LOWER(:new) AND LOWER(aliasname) != LOWER(:old)
            """), {"new": new_name, "old": old_aliasname}).scalar()

            if exists:
                print(f"❌ Alias '{new_name}' already exists")
                return {"error": f"Alias '{new_name}' already exists."}

            # ✅ Update aliases table
            update_result = conn.execute(text("""
                UPDATE aliases SET aliasname = :new_name WHERE aliasname = :old_name
            """), {"new_name": new_name, "old_name": old_aliasname})

            print(f"✅ UPDATE affected {update_result.rowcount} row(s)")

            # ✅ Cascade to file_uploads
            cascade_result = conn.execute(text("""
                UPDATE file_uploads SET Alias = :new_name WHERE Alias = :old_name
            """), {"new_name": new_name, "old_name": old_aliasname})

            print(f"🔁 Cascade UPDATE affected {cascade_result.rowcount} row(s)")

        # Only return success if we got here
        print(f"🎉 Successfully updated '{old_aliasname}' → '{new_name}'")
        return {"message": f"Alias updated from '{old_aliasname}' to '{new_name}'."}

    except Exception as e:
        print(f"💥 Error in edit_alias: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return {"error": "Internal server error"}

# -------------------------
# DELETE: Delete an alias
# -------------------------
@router.delete("/api/aliases/{aliasname}")
def delete_alias(aliasname: str):
    try:
        with engine.begin() as conn:
            row = conn.execute(text("""
                SELECT isassigned FROM aliases WHERE aliasname = :name
            """), {"name": aliasname}).fetchone()

            if not row:
                return {"error": "Alias not found"}

            if row.isassigned:
                return {"error": "Cannot delete an assigned alias"}

            conn.execute(text("DELETE FROM aliases WHERE aliasname = :name"), {"name": aliasname})

        return {"message": "Alias deleted successfully"}

    except Exception as e:
        print(f"Delete error: {e}")
        return {"error": "Internal server error"}