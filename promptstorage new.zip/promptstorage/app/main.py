
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from backend import crud_api, prompt_manager2,metadata_excel,value_manager,record_entry,manage_clients,manage_clients2,alias_store,upload_file,template_store,template_mapping
app = FastAPI()
 
app.mount("/static", StaticFiles(directory="static"), name="static")
 
#app.include_router(crud_api.router)
app.include_router(prompt_manager2.router)
app.include_router(metadata_excel.router)
app.include_router(value_manager.router)
app.include_router(record_entry.router)
app.include_router(manage_clients.router)
app.include_router(alias_store.router)
app.include_router(upload_file.router)
app.include_router(template_store.router)
app.include_router(template_mapping.router)
#app.include_router(template_mapping.router)

#app.include_router(manage_clients2.router)
 
 
 