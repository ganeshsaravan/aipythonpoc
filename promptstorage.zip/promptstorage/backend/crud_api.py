from fastapi import APIRouter, Query, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text
import pandas as pd
import numpy as np

# 🔧 Initialize router and templates
router = APIRouter()
templates = Jinja2Templates(directory="templates")

# 🔗 Database config from second code
DB_CONFIG = {
    "user": "postgres",
    "password": "Password%40123%21",
    "host": "localhost",
    "port": "5432",
    "database": "promptstore"
}

# 🔌 SQLAlchemy engine
engine = create_engine(
    f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
)

# 🧭 Table mapping
TABLE_MAP = {
    "main": "Master_Input_JSON_Table",
    "group": "Group_Table",
    "link": "Link_Table"
}

# 🖥️ Serve index.html from templates
@router.get("/index", response_class=HTMLResponse)
async def serve_ui(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# 📊 Get table data
@router.get("/data")
async def get_table_data(table: str = Query(...)):
    if table not in TABLE_MAP:
        raise HTTPException(status_code=400, detail="Invalid table name")
    table_name = TABLE_MAP[table]
    try:
        with engine.connect() as conn:
            df = pd.read_sql(f'SELECT * FROM "{table_name}"', conn)
        df.replace({np.nan: None, pd.NaT: None, np.inf: None, -np.inf: None}, inplace=True)
        return JSONResponse(content=df.to_dict(orient="records"))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ➕ Create new row
@router.post("/create")
async def create_row(table: str = Query(...), row: dict = None):
    if table not in TABLE_MAP:
        raise HTTPException(status_code=400, detail="Invalid table name")
    table_name = TABLE_MAP[table]

    if not row or not isinstance(row, dict):
        raise HTTPException(status_code=400, detail="No row data provided")

    try:
        row = {k: (None if v == "" else v) for k, v in row.items()}
        clean_row = {k: v for k, v in row.items() if v is not None}
        if not clean_row:
            raise HTTPException(status_code=400, detail="No valid values to insert")

        columns = ", ".join([f'"{col}"' for col in clean_row.keys()])
        values = ", ".join([f":{col}" for col in clean_row.keys()])
        query = text(f'INSERT INTO "{table_name}" ({columns}) VALUES ({values})')

        with engine.begin() as conn:
            result = conn.execute(query, clean_row)
            if result.rowcount == 0:
                raise HTTPException(status_code=500, detail="Row insertion failed")

        return {"status": "success", "message": "Row created successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 🔄 Update row
@router.put("/update")
async def update_row(table: str = Query(...), pk: str = Query(...), row: dict = None):
    if table not in TABLE_MAP:
        raise HTTPException(status_code=400, detail="Invalid table name")
    table_name = TABLE_MAP[table]
    if not row:
        raise HTTPException(status_code=400, detail="No update data provided")
    try:
        pk_col = get_primary_key(table_name)
        row = {k: (None if v == "" else v) for k, v in row.items()}
        set_clause = ", ".join([f'"{col}" = :{col}' for col in row.keys()])
        query = text(f'UPDATE "{table_name}" SET {set_clause} WHERE "{pk_col}" = :pk')
        with engine.begin() as conn:
            result = conn.execute(query, {**row, "pk": pk})
            if result.rowcount == 0:
                raise HTTPException(status_code=404, detail="No row updated. Check primary key.")
        return {"status": "success", "message": "Row updated successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 🗑️ Delete row
@router.delete("/delete")
async def delete_row(table: str = Query(...), pk: str = Query(...)):
    if table not in TABLE_MAP:
        raise HTTPException(status_code=400, detail="Invalid table name")
    table_name = TABLE_MAP[table]
    try:
        pk_col = get_primary_key(table_name)
        query = text(f'DELETE FROM "{table_name}" WHERE "{pk_col}" = :pk')
        with engine.begin() as conn:
            result = conn.execute(query, {"pk": pk})
            if result.rowcount == 0:
                raise HTTPException(status_code=404, detail="No row deleted. Check primary key.")
        return {"status": "success", "message": "Row deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# 🔍 Get primary key column
def get_primary_key(table_name: str) -> str:
    with engine.connect() as conn:
        quoted_table = f'"{table_name}"'
        result = conn.execute(text(f"""
            SELECT a.attname
            FROM pg_index i
            JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
            WHERE i.indrelid = '{quoted_table}'::regclass AND i.indisprimary;
        """))
        pk = result.scalar()
        if not pk:
            raise HTTPException(status_code=500, detail="Primary key not found")
        return pk
