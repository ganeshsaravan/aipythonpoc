from fastapi import APIRouter, Form, File, UploadFile, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, TIMESTAMP, insert, select
from datetime import datetime
import openpyxl
import tempfile
import pandas as pd
import psycopg2
import json
import os
import urllib.parse

router = APIRouter()

templates = Jinja2Templates(directory="templates")

UPLOAD_FOLDER = "uploaded_docs"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

DB_USER = "postgres"
DB_PASSWORD = "Password%40123%21"
DB_HOST = "localhost"
DB_PORT = "5432"
DB_NAME = "metadatastore"
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

plain_password = urllib.parse.unquote(DB_PASSWORD)

engine = create_engine(DATABASE_URL)
metadata = MetaData()

document_metadata = Table(
    "document_metadata",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("document_name", String, nullable=False),
    Column("alias_name", String),
    Column("use_set", String),
    Column("sheet_name", String),
    Column("uploaded_at", TIMESTAMP, default=datetime.utcnow),
)

metadata.create_all(engine)

last_table_name = None
last_excel_filename = None
last_start_row = None
json_mapping_path = "db_to_excel_header_map.json"

@router.get("/metadataupload", response_class=HTMLResponse)
async def upload_metadata_page(request: Request):
    with engine.connect() as conn:
        docs = conn.execute(select(document_metadata)).fetchall()
    return templates.TemplateResponse("upload_metadata.html", {"request": request, "documents": docs})

@router.post("/upload")
async def upload_document(
    request: Request,
    document: UploadFile = File(...),
    alias_name: str = Form(...),
    use_set: str = Form(...),
    sheet_name: str = Form(...)
):
    file_location = os.path.join(UPLOAD_FOLDER, document.filename)
    with open(file_location, "wb") as buffer:
        buffer.write(await document.read())

    with engine.connect() as conn:
        conn.execute(insert(document_metadata).values(
            document_name=document.filename,
            alias_name=alias_name,
            use_set=use_set,
            sheet_name=sheet_name,
            uploaded_at=datetime.utcnow()
        ))
        documents = conn.execute(select(document_metadata)).fetchall()

    return templates.TemplateResponse("upload_metadata.html", {
        "request": request,
        "message": "Document uploaded and metadata saved successfully.",
        "message_type": "success",
        "documents": documents
    })

@router.get("/excel", response_class=HTMLResponse)
async def upload_excel_page(request: Request):
    return templates.TemplateResponse("upload_excel.html", {"request": request})

@router.post("/upload_excel")
async def upload_excel(
    request: Request,
    table_name: str = Form(...),
    start_row: int = Form(...),
    excel_file: UploadFile = File(...)
):
    global last_table_name, last_excel_filename, last_start_row

    try:
        excel_filename = excel_file.filename
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as temp_file:
            temp_file.write(await excel_file.read())
            excel_path = temp_file.name

        workbook = openpyxl.load_workbook(excel_path)
        sheet = workbook.active
        header_row = start_row - 1

        valid_headers, valid_indices = [], []
        for idx, cell in enumerate(sheet[header_row]):
            if cell.value and str(cell.value).strip():
                valid_headers.append(str(cell.value).strip().lower())
                valid_indices.append(idx)

        data = []
        for row in sheet.iter_rows(min_row=start_row, values_only=True):
            if all(cell is None for cell in row):
                break
            filtered_row = [row[i] for i in valid_indices if i < len(row)]
            data.append(filtered_row)

        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME,
            user=DB_USER,
            password=plain_password
        )
        cur = conn.cursor()

        column_defs = ",\n".join([f'"{col}" TEXT' for col in valid_headers])
        cur.execute(f'CREATE TABLE IF NOT EXISTS "{table_name}" (\n{column_defs}\n);')

        columns_sql = ', '.join([f'"{col}"' for col in valid_headers])
        for row in data:
            placeholders = ', '.join(['%s'] * len(valid_headers))
            cur.execute(f'INSERT INTO "{table_name}" ({columns_sql}) VALUES ({placeholders})', row)

        conn.commit()

        cur.execute(f'SELECT * FROM "{table_name}" LIMIT 1;')
        db_columns = [desc[0].strip().lower() for desc in cur.description]
        mapping = {db: excel for db, excel in zip(db_columns, valid_headers)}
        with open(json_mapping_path, "w") as f:
            json.dump(mapping, f, indent=4)

        cur.close()
        conn.close()
        os.remove(excel_path)

        last_table_name = table_name
        last_excel_filename = excel_filename
        last_start_row = start_row

        return templates.TemplateResponse("upload_excel.html", {
            "request": request,
            "message": f"✅ Inserted {len(data)} rows into '{table_name}' and mapping saved.",
            "message_type": "success"
        })

    except Exception as e:
        return templates.TemplateResponse("upload_excel.html", {
            "request": request,
            "message": f"❌ Upload Error: {str(e)}",
            "message_type": "error"
        })

@router.post("/download")
async def generate_excel(request: Request, template_excel: UploadFile = File(...)):
    global last_table_name, last_excel_filename, last_start_row

    try:
        if not last_table_name or not last_excel_filename or not last_start_row:
            return templates.TemplateResponse("upload_excel.html", {
                "request": request,
                "message": "❌ No previous upload info found.",
                "message_type": "error"
            })

        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as temp_template:
            temp_template.write(await template_excel.read())
            template_path = temp_template.name

        with open(json_mapping_path, "r") as f:
            header_map = json.load(f)

        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME,
            user=DB_USER,
            password=plain_password
        )
        cur = conn.cursor()
        cur.execute(f'SELECT * FROM "{last_table_name}";')
        rows = cur.fetchall()
        colnames = [desc[0].strip().lower() for desc in cur.description]
        cur.close()
        conn.close()

        df = pd.DataFrame(rows, columns=colnames)
        valid_keys = [key for key in header_map if key in df.columns]
        mapped_df = df[valid_keys].rename(columns={k: header_map[k] for k in valid_keys})

        workbook = openpyxl.load_workbook(template_path)
        sheet = workbook.active

        for row_idx, row_data in enumerate(mapped_df.values, start=last_start_row):
            for col_idx, cell_value in enumerate(row_data, start=1):
                cell = sheet.cell(row=row_idx, column=col_idx)
                if not isinstance(cell, openpyxl.cell.cell.MergedCell):
                    cell.value = cell_value

        output_path = os.path.join("output", f"filled_{last_excel_filename}")
        os.makedirs("output", exist_ok=True)
        workbook.save(output_path)

        return FileResponse(
            path=output_path,
            filename=f"filled_{last_excel_filename}",
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

    except Exception as e:
        return templates.TemplateResponse("upload_excel.html", {
            "request": request,
            "message": f"❌ Download Error: {str(e)}",
            "message_type": "error"
        })
