from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from backend import crud_api, prompt_manager,metadata_excel
app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")

app.include_router(crud_api.router)
app.include_router(prompt_manager.router)
app.include_router(metadata_excel.router)
