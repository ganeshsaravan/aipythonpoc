# upload_utils.py
import os
from fastapi import UploadFile
from typing import List
from datetime import datetime

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx', 'xlsx', 'xls', 'jpg', 'jpeg', 'png'}

def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_docs_to_chromadb(files: List[UploadFile], folder: str) -> int:
    os.makedirs(folder, exist_ok=True)
    saved_count = 0

    for file in files:
        if file and allowed_file(file.filename):
            # Sanitize filename to prevent path traversal
            filename = file.filename.replace("..", "").strip("/\\")
            full_path = os.path.join(folder, filename)

            os.makedirs(os.path.dirname(full_path), exist_ok=True)

            with open(full_path, "wb") as out_file:
                content = file.file.read()
                out_file.write(content)

            saved_count += 1

    return saved_count
