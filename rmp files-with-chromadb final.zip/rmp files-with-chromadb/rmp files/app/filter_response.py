from bs4 import BeautifulSoup
import re

def remove_document_name_from_html(html_content):
    
    # cleaned = re.sub(r'\bbxu\w*\b', '', html_content, flags=re.IGNORECASE)
    # return ''.join(cleaned.split())
 # Remove 'bxu' followed by any word
    cleaned = re.sub(r'\bbxu\w*\b', '', html_content, flags=re.IGNORECASE)
    
    # Clean up extra spaces by splitting and joining
    cleaned = ''.join(cleaned.split())

    # Parse the cleaned content using BeautifulSoup
    soup = BeautifulSoup(cleaned, 'html.parser')
    
    # Prettify the HTML (this will ensure it is well-formatted)
    beautified_html = soup.prettify()

    return beautified_html
 
    # soup = BeautifulSoup(html_content, 'html.parser')

    # # Remove occurrences from text nodes
    # for text_element in soup.find_all(text=True):
    #     if document_name in text_element:
    #         text_element.replace_with(text_element.replace(document_name, ""))

    # # Remove occurrences from tag attributes (href, class, etc.)
    # for tag in soup.find_all(True):  # Iterate through all tags
    #     for attribute in tag.attrs:
    #         if document_name in tag[attribute]:
    #             tag[attribute] = tag[attribute].replace(document_name, "")

    # return str(soup)