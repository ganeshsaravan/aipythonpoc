from fastapi import APIRouter, Request, Form, UploadFile, File
from fastapi.responses import RedirectResponse, FileResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select, insert, update
from models import engine, submissions, users  # SQLAlchemy Core tables
from email_utils import send_approval_email, notify_sender
import os
import shutil
import uuid
from datetime import datetime
from product_folderview import router as product_router
from uploadfiles import save_files_to_folder
from typing import List
from ract_download import router as ract_router
import logging
import sys
from config.config_loader import ConfigLoader
from config.model_factory import get_llm_and_embedder
from documents_ingestion.upload_docs_to_chromadb import save_docs_to_chromadb
from documents_ingestion.load_documents import load_documents
from documents_ingestion.chunker import split_documents, create_chunks_and_metas, split_by_sections, generate_all_chunks
from documents_ingestion.embedder import embed_chunks_with_dynamic_backend
from documents_ingestion.vectorizer import document_vectorize, document_vectorize_by_section
from documents_ingestion.move_files_to_archive import move_files_to_archive
from documents_ingestion.remove_empty_folders import remove_empty_folders
from retrieval.retrieve_content_prompt import retrieve_content_prompt
from documents_ingestion.delete_collection import delete_collection
# --- Logging setup ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)

config_loader = ConfigLoader()
llm, embedder = get_llm_and_embedder(config_loader)
pipeline_config = {
    "embedder": embedder,
    "llm": llm,
    "chroma_host": config_loader.get("storage", "chroma", "host"),
    "chroma_port": config_loader.get("storage", "chroma", "port"),
    "collection": config_loader.get("storage", "chroma", "collection_name"),
    "max_results": config_loader.get("generation", "max_results", default=5),
    "temperature": config_loader.get("generation", "temperature", default=0.4),
    "max_tokens": config_loader.get("generation", "max_tokens", default=2048),
    "sotafile_path": config_loader.get("data", "sotafile_path"),
    "where_filter": "",
    "full_document_search": False
}

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

router = APIRouter()
templates = Jinja2Templates(directory="templates")

#DEFAULT_APPROVERS = ["ganesh000030@gmail.com", "ganeshsaravanakanisetty@gmail.com"]
DEFAULT_APPROVERS = ["airagenuser1@hcltech.com", "airagenuser2@hcltech.com"]

def get_logged_in_username(request: Request):
    return request.cookies.get("username", "")

@router.get("/")
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "username": get_logged_in_username(request)})

@router.get("/home")
def homeindex(request: Request):
    return templates.TemplateResponse("home.html", {"request": request, "username": get_logged_in_username(request)})

@router.get("/register")
def register_get(request: Request):
    return templates.TemplateResponse("register.html", {"request": request, "error": None})

@router.post("/register")
def register_post(request: Request, username: str = Form(...), password: str = Form(...),
                  gmail: str = Form(...)):
                   #gmail_password: str = Form(...),
                 # app_password: str = Form(...), dob: str = Form(...)):
    with engine.connect() as conn:
        if conn.execute(select(users).where(users.c.username == username)).first():
            return templates.TemplateResponse("register.html", {"request": request, "error": "Username already exists"})
        if conn.execute(select(users).where(users.c.gmail == gmail)).first():
            return templates.TemplateResponse("register.html", {"request": request, "error": "Email already exists"})
 
    with engine.begin() as conn:
        conn.execute(insert(users).values(
            username=username,
            password=password,
            gmail=gmail,
            #gmail_password=gmail_password,
            gmail_password="1234",
            #app_password=app_password,
            app_password="aabnchkhmcnviznw",
            #dob=datetime.strptime(dob, "%Y-%m-%d").date()
            dob="2020-11-15"
        ))
    return RedirectResponse("/login", status_code=303)

@router.get("/login")
def login_get(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})

@router.post("/login")
def login_post(request: Request, username: str = Form(...), password: str = Form(...)):
    with engine.connect() as conn:
        user = conn.execute(select(users).where(users.c.username == username, users.c.password == password)).first()
        if user:
            response = RedirectResponse("/home", status_code=303)
            response.set_cookie(key="username", value=username)
            return response
        elif username == "approver1" and password == "approver1":
            response = RedirectResponse("/approve", status_code=303)
            response.set_cookie(key="username", value="approver1")
            return response
        elif username == "approver2" and password == "approver2":
            response = RedirectResponse("/approve", status_code=303)
            response.set_cookie(key="username", value="approver2")
            return response
    return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid credentials"})

@router.get("/logout")
def logout(request: Request):
    response = RedirectResponse("/", status_code=303)
    response.delete_cookie("username")
    return response

@router.get("/sender")
def sender_get(request: Request):
    username = get_logged_in_username(request)
    with engine.connect() as conn:
        subs = conn.execute(select(submissions)).fetchall()
        user = conn.execute(select(users).where(users.c.username == username)).first()
    return templates.TemplateResponse("sender.html", {
        "request": request,
        "submissions": subs,
        "user": user,
        "username": username,
        "message": request.query_params.get("message")
    })

@router.post("/sender")
async def upload_file(request: Request, file: UploadFile = File(...), folder: str = Form(...)):
    username = get_logged_in_username(request)

    # Fetch user details
    with engine.connect() as conn:
        user = conn.execute(select(users).where(users.c.username == username)).first()

    submission_id = str(uuid.uuid4())
    folder_path = os.path.join(UPLOAD_DIR, folder)
    os.makedirs(folder_path, exist_ok=True)
    filepath = os.path.join(folder_path, f"{submission_id}_{file.filename}")

    # Save the uploaded file
    with open(filepath, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # Insert submission record into DB
    with engine.begin() as conn:
        conn.execute(insert(submissions).values(
            id=submission_id,
            filename=file.filename,
            filepath=filepath,
            folder=folder,
            status="Level 1 Approval Pending",
            sender_email="kanisettyganeshsaravana@gmail.com",
            sender_password="aabnchkhmcnviznw",
            approver_email=DEFAULT_APPROVERS[0],
            approval_level=1,
            max_approval_level=len(DEFAULT_APPROVERS)
        ))

    # 🔍 Fetch the inserted row to pass as a Row object (not dict) to send_approval_email
    with engine.connect() as conn:
        submission = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()

    # ✅ Now pass the actual Row to the email function
    send_approval_email(submission)

    return RedirectResponse("/sender?message=File submitted successfully", status_code=303)


@router.get("/approve")
def approve_get(request: Request):
    username = get_logged_in_username(request)

    with engine.connect() as conn:
        if username == "approver1":
            # Show only Level 1 Approval Pending files
            pending = conn.execute(
                select(submissions).where(submissions.c.status == "Level 1 Approval Pending")
            ).fetchall()
        elif username == "approver2":
            # Show only Level 2 Approval Pending files
            pending = conn.execute(
                select(submissions).where(submissions.c.status == "Level 2 Approval Pending")
            ).fetchall()
        else:
            # Non-approvers shouldn't access this
            return RedirectResponse("/login", status_code=303)

    return templates.TemplateResponse("approve.html", {
        "request": request,
        "pending": pending,
        "username": username
    })

@router.post("/approve")
def submit_decision(request: Request, submission_id: str = Form(...), action: str = Form(...)):
    username = get_logged_in_username(request)

    if username not in ["approver1", "approver2"]:
        return RedirectResponse("/login", status_code=303)

    with engine.begin() as conn:
        sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
        if not sub:
            return RedirectResponse("/approve", status_code=303)

        current_level = sub.approval_level
        max_level = sub.max_approval_level

        if action == "approve":
            if current_level < max_level:
                new_level = current_level + 1
                conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                    approval_level=new_level,
                    status=f"Level {new_level} Approval Pending",
                    approver_email=DEFAULT_APPROVERS[new_level - 1]
                ))
                updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
                send_approval_email(updated_sub)
            else:
                conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                    status="Approved"
                ))
                updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
                notify_sender(updated_sub)

        elif action == "refer":
            conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                status="Referred Back"
            ))
            updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
            notify_sender(updated_sub)

    return RedirectResponse("/approve", status_code=303)


@router.get("/email/decision/{submission_id}/{action}")
def email_decision(submission_id: str, action: str):
    with engine.begin() as conn:
        sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
        if not sub or not sub.status.startswith("Level") or "Pending" not in sub.status:
            return HTMLResponse("Invalid submission", status_code=400)

        if action == "approve":
            if sub.approval_level < sub.max_approval_level:
                new_level = sub.approval_level + 1
                conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                    approval_level=new_level,
                    status=f"Level {new_level} Approval Pending",
                    approver_email=DEFAULT_APPROVERS[new_level - 1]
                ))

                updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
                send_approval_email(updated_sub)

            else:
                conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                    status="Approved"
                ))

                updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
                notify_sender(updated_sub)
        else:
            conn.execute(update(submissions).where(submissions.c.id == submission_id).values(
                status="Referred Back"
            ))

            updated_sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
            notify_sender(updated_sub)

    return HTMLResponse(f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Decision Recorded</title>
            <script>
                alert("The file '{sub.filename}' has been {action}d.");
                window.close();
            </script>
        </head>
        <body>
            <p>If this tab doesn't close automatically, you can close it manually.</p>
        </body>
        </html>
    """)

@router.get("/download/{submission_id}")
def download_file(submission_id: str):
    with engine.connect() as conn:
        sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()
    if sub:
        return FileResponse(sub.filepath, filename=sub.filename)
    return {"error": "File not found"}

@router.get("/folder")
def folder(request: Request):
    username = get_logged_in_username(request)
    with engine.connect() as conn:
        rows = conn.execute(select(submissions)).fetchall()
    folders = {}
    for sub in rows:
        key = sub.folder or "Uncategorized"
        folders.setdefault(key, []).append(sub)
    return templates.TemplateResponse("folder.html", {"request": request, "folders": folders, "username": username})

# @router.get("/folderview")
# def folderview_get(request: Request, folder: str = None):
#     username = get_logged_in_username(request)
#     with engine.connect() as conn:
#         if folder:
#             result = conn.execute(select(submissions).where(submissions.c.folder == folder)).fetchall()
#             return templates.TemplateResponse(
#                 "folderview.html",
#                 {
#                     "request": request,
#                     "folder_name": folder,
#                     "files": result,
#                     "username": username
#                 }
#             )
#         else:
#             # fallback if no folder specified
#             return RedirectResponse("/folder", status_code=303)

@router.get("/folderview")
def folderview_get(request: Request, folder: str = None):
    username = get_logged_in_username(request)
    with engine.connect() as conn:
        if folder:
            result = conn.execute(
                select(
                    submissions.c.id,
                    submissions.c.filename,                
                    submissions.c.upload_time,
                ).where(submissions.c.folder == folder)
            ).fetchall()
            return templates.TemplateResponse(
                "folderview.html",
                {
                    "request": request,
                    "folder_name": folder,
                    "files": result,
                    "username": username
                }
            )
        return RedirectResponse("/folder", status_code=303)

@router.get("/download/{file_id}")
def download_file(file_id: int):
    with engine.connect() as conn:
        file = conn.execute(
            select(submissions.c.filename, submissions.c.folder)
            .where(submissions.c.id == file_id)
        ).first()
        if file:
            folder_path = os.path.join("uploaded_files", file.folder)
            file_path = os.path.join(folder_path, file.filename)
            if os.path.exists(file_path):
                return FileResponse(file_path, filename=file.filename)
    return {"error": "File not found"}

@router.get("/approvestatus/{submission_id}")
def approval_status(submission_id: str, request: Request):
    with engine.connect() as conn:
        sub = conn.execute(select(submissions).where(submissions.c.id == submission_id)).first()

    if not sub:
        return HTMLResponse("Submission not found", status_code=404)

    status = sub.status

    if status == "Approved":
        level1_status = "Approved"
        level2_status = "Approved"
    elif status == "Referred Back":
        # We assume if it was referred back, it could be either level
        if sub.approval_level == 1:
            level1_status = "Referred Back"
            level2_status = "Pending"
        else:
            level1_status = "Approved"
            level2_status = "Referred Back"
    elif "Level 1" in status:
        level1_status = "Pending"
        level2_status = "Pending"
    elif "Level 2" in status:
        level1_status = "Approved"
        level2_status = "Pending"
    else:
        level1_status = "Pending"
        level2_status = "Pending"

    return templates.TemplateResponse("approvestatus.html", {
    "request": request,
    "submission": sub,
    "username": get_logged_in_username(request),
    "level1_status": level1_status,
    "level2_status": level2_status,
    "approver2_email": DEFAULT_APPROVERS[1] if len(DEFAULT_APPROVERS) > 1 else ""
})

@router.get("/upload")
def upload_page(request: Request, message: str = "", error: str = ""):
    username = get_logged_in_username(request)
    return templates.TemplateResponse("uploadfiles.html", {
        "request": request,
        "message": message,
        "error": error,
        "username": username
    })


@router.post("/upload")
async def upload_files_to_folder(
    request: Request,
    folder: str = Form(...),
    files: List[UploadFile] = File(...)
):
    username = get_logged_in_username(request)
    try:
        count = save_files_to_folder(files, folder)
        return templates.TemplateResponse("uploadfiles.html", {
            "request": request,
            "message": f"{count} file(s) uploaded successfully to folder '{folder}'",
            "error": "",
            "username": username
        })
    except Exception as e:
        return templates.TemplateResponse("uploadfiles.html", {
            "request": request,
            "message": "",
            "error": f"Upload failed: {str(e)}",
            "username": username
        })

@router.get("/uploaddocs")
def uploaddocs_page(request: Request, message: str = "", error: str = ""):
    username = get_logged_in_username(request)
    return templates.TemplateResponse("uploaddocs.html", {
        "request": request,
        "message": message,
        "error": error,
        "username": username
    })
@router.post("/uploaddocs")
async def upload_docs(
    request: Request,
    folder: str = Form(...),
    files: List[UploadFile] = File(...)
):
    username = get_logged_in_username(request)
    logging.info(f"Received {len(files)} files for upload in folder: {folder}")
    try:
        # Save uploaded files
        count = save_docs_to_chromadb(files, folder)
        logging.info(f"{count} files uploaded to folder: {folder}")
        delete_collection(
            pipeline_config["chroma_host"],
            pipeline_config["chroma_port"],
            pipeline_config["collection"]
        )
        # Start vectorization pipeline
        documents = load_documents(folder)
        chunks = generate_all_chunks(documents)
        logging.info(f"Split documents successfully: {chunks}")

        embeddings, valid_chunks = embed_chunks_with_dynamic_backend(chunks, config_loader)

        if not embeddings or not valid_chunks:
            logging.warning("No valid embeddings or chunks were generated. Skipping vectorization.")
            vectorize_response = {"status": "No chunks to embed"}
        else:
            logging.info(f"Successfully embedded {len(valid_chunks)} chunks")
            vectorize_response = document_vectorize_by_section(
                pipeline_config["chroma_host"],
                pipeline_config["chroma_port"],
                pipeline_config["collection"],
                valid_chunks,
                embeddings
            )
            logging.info(f"Vectorization successful: {vectorize_response}")

        # Cleanup
        move_files_to_archive(folder, config_loader.get("data", "archive_folder"))
        remove_empty_folders(folder)

        return templates.TemplateResponse("uploaddocs.html", {
            "request": request,
            "message": f"{count} file(s) uploaded and vectorized successfully.",
            "error": "",
            "username": username
        })

    except Exception as e:
        logging.error(f"Upload/vectorization failed: {str(e)}")
        return templates.TemplateResponse("uploaddocs.html", {
            "request": request,
            "message": "",
            "error": f"Upload/vectorization failed: {str(e)}",
            "username": username
        })


@router.get("/chatbot")
def prompt(request: Request):
    return templates.TemplateResponse("chatbot.html", {"request": request, "username": get_logged_in_username(request)})

from markdown_chat import render_markdown_to_html
from filter_response import remove_document_name_from_html
@router.post("/chatbot")
def retrieval_content_from_chromadb_prompt(
    request: Request, 
    prompt_query: str = Form(...), 
    full_doc_search: bool = Form(False), 
    user_query: str = Form(...)):
    username = get_logged_in_username(request)

    logging.info(f"Prompt data: {prompt_query} | Full Document Search: {full_doc_search} | User Query: {user_query}")
    try:
        response = retrieve_content_prompt(pipeline_config, user_query, prompt_query, full_doc_search)
        markdown_response=render_markdown_to_html(response)
        #filt_response=remove_document_name_from_html(markdown_response)
        return templates.TemplateResponse("chatbot.html", {
                "request": request,
                "message": markdown_response,
                #"message": filt_response,
                "error": "",
                "username": username
            })

    except Exception as e:
        logging.error(f"Failed to retrieve data from chromadb: {str(e)}")
        return templates.TemplateResponse("chatbot.html", {
            "request": request,
            "message": "",
            "error": f"Failed to retrieve data from chromadb: {str(e)}",
            "username": username
        })


@router.get("/UpdateRact", response_class=HTMLResponse)
def show_download_page(request: Request):
    username = get_logged_in_username(request)
    return templates.TemplateResponse("download_ract.html", {
        "request": request,
        "username": username
    })

def include_routes(app):
    app.include_router(router)
    app.include_router(product_router)
    app.include_router(ract_router)