import smtplib
from email.message import EmailMessage
from email.utils import formataddr

def send_approval_email(submission):
    DEFAULT_APPROVERS = ["airagenuser1@hcltech.com", "airagenuser2@hcltech.com"]
    
    # Safely get approver email from the list based on level
    try:
        approver_email = DEFAULT_APPROVERS[submission.approval_level - 1]
    except IndexError:
        print("❌ No approver email found for level:", submission.approval_level)
        return

    msg = EmailMessage()
    msg["Subject"] = f"Approval Needed - Level {submission.approval_level}"
    msg["From"] = formataddr(("Aira DHF","airadhfdemo@gmail.com")) #submission.sender_email
    msg["To"] = approver_email

    download_link = f"http://10.134.44.232:8001/download/{submission.id}"
    approve_link = f"http://10.134.44.232:8001/email/decision/{submission.id}/approve"
    refer_link = f"http://10.134.44.232:8001/email/decision/{submission.id}/refer"

    msg.add_alternative(f"""
    <html>
        <body>
            <p>Hello Approver,<br><br>
            A file '<strong>{submission.filename}</strong>' has been submitted for your approval (Level {submission.approval_level}).<br>
            <a href='{download_link}'>Download File</a><br><br>
            <a href='{approve_link}'>Approve</a> | <a href='{refer_link}'>Refer Back</a>
            </p>
        </body>
    </html>
    """, subtype='html')

    try:
        with open(submission.filepath, "rb") as f:
            msg.add_attachment(f.read(), maintype='application', subtype='octet-stream', filename=submission.filename)
    except FileNotFoundError:
        print(f"❌ File not found: {submission.filepath}")
        return

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(submission.sender_email, submission.sender_password)
            smtp.send_message(msg)
        print(f"✅ Approval email sent to Level {submission.approval_level}")
    except Exception as e:
        print(f"❌ Error sending approval email: {e}")


def notify_sender(submission):
    msg = EmailMessage()
    msg["Subject"] = f"Your file '{submission.filename}' was {submission.status}"
    msg["From"] ="nomain.@example.com"
    msg["To"] = submission.sender_email

    msg.set_content(f"Hi,\n\nYour file '{submission.filename}' was {submission.status.lower()} by the approver.\n\nThank you.")

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(submission.sender_email, submission.sender_password)
            smtp.send_message(msg)
        print("✅ Sender notified.")
    except Exception as e:
        print(f"❌ Error notifying sender: {e}")
