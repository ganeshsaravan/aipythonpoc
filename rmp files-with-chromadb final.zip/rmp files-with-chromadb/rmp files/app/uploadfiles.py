# upload_utils.py
import os
import shutil
from fastapi import UploadFile
from datetime import datetime

UPLOAD_DIR = "upload product files"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def save_files_to_folder(files: list[UploadFile], folder: str) -> int:
    folder_path = os.path.join(UPLOAD_DIR, folder)  # folder name stays clean, no timestamp here
    os.makedirs(folder_path, exist_ok=True)
    count = 0
    for file in files:
        filename = file.filename  # use original filename as is
        filepath = os.path.join(folder_path, filename)

        with open(filepath, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        count += 1
    return count