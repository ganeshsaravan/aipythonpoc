import markdown

def render_markdown_to_html(input):
    html=markdown.markdown(input)
    return html