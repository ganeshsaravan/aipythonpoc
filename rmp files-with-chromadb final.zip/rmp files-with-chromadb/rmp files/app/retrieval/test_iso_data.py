
def get_test_iso_data():
# Inline test data
    document_outputs = [
        {
            "description": "Aeronautical telecommunications - Automatic dependent surveillance - broadcast (ADS-B) - Part 1: Technical characteristics",
            "Code_1": "N/A",
            "Code_2": "ISO 16782:2015",
            "Code_3": "N/A",
            "Code_4": "N/A"
        },
        {
            "description": "Biological evaluation of medical devices - Part 18: Tests for systemic toxicity",
            "Code_1": "N/A",
            "Code_2": "EN ISO 10993-18:2020",
            "Code_3": "N/A",
            "Code_4": "N/A"            
        },
        {
            "description": "Medical devices - Application of risk management principles to medical devices",
            "Code_1": "N/A",
            "Code_2": "BS EN ISO 14971:2012+A1:2014",
            "Code_3": "N/A",
            "Code_4": "N/A"            
        },
        {
            "description": "Quality management systems - Requirements for regulatory purposes in the design, manufacture, packaging, labeling, storage, installation and servicing of medical devices",
            "Code_1": "N/A",
            "Code_2": "EN ISO 13485:2016",
            "Code_3": "N/A",
            "Code_4": "N/A"            
        },
        {
            "description": "Medical devices — Guidance on the exchange of information — Particular requirements for the identification and traceability of returned medical devices",
            "Code_1": "N/A",
            "Code_2": "N/A",
            "Code_3": "ISO 14971:2012",
            "Code_4": "N/A"
        },
        {
           "description": "",
            "Code_1": "N/A",
            "Code_2": "N/A",
            "Code_3": "ISO 13485:2016",
            "Code_4": "N/A"
        },
        {
            "description": "",
            "Code_1": "N/A",
            "Code_2": "N/A",
            "Code_3": "BS EN ISO 14971:2019+A11:2021",
            "Code_4": "N/A"
        }
    ]
    return document_outputs

