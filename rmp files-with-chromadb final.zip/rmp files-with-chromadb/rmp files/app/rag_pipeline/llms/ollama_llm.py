from .base import BaseLLM
import requests
import json

class OllamaLLM(BaseLLM):
    def __init__(self, model: str, base_url: str):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()  # reuse session for performance

    def generate(self, prompt, context, question, temperature, max_tokens):
        if '"response": ["No Trace"]' in prompt:
            return '{"response": ["No Trace"]}'

        try:
            response = self.session.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    "num_predict": 1024
                },
                stream=True,
                timeout=180  # set timeout to avoid hanging
            )
            response.raise_for_status()
            full_response = ""
            for line in response.iter_lines(decode_unicode=True):
                if line:
                    full_response += json.loads(line).get("response", "")
            return full_response.strip()
        except Exception as e:
            return f"[Error in OllamaModel]: {e}"
