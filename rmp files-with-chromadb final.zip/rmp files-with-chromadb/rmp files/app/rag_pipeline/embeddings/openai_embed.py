import openai
from rag_pipeline.embeddings.base import EmbeddingBackend

class OpenAIEmbedder(EmbeddingBackend):
    def __init__(self, model: str, api_key: str, base_url: str):
        self.model = model
        self.api_key = api_key
        self.base_url = base_url

        # Set OpenAI API settings globally
        openai.api_key = self.api_key
        openai.base_url = self.base_url

    def embed(self, text: str) -> list[float]:
        if not text.strip():
            return []
        try:
            response = openai.Embedding.create(
                input=text,
                model=self.model,
            )
            return response["data"][0]["embedding"]
        except Exception as e:
            print(f"[OpenAIEmbedder] Error generating embedding: {e}")
            return []

    def embed_section_chunks(self, chunks):
        embeddings = []
        valid_chunks = []
        for chunk in chunks:
            text = chunk.get("content", "")
            if not text.strip():
                continue
            embedding = self.embed(text)
            if embedding:
                embeddings.append(embedding)
                valid_chunks.append(chunk)
        return embeddings, valid_chunks
