import pandas as pd
import json
from pathlib import Path
from sqlalchemy import create_engine
 
# ---------------------- CONFIG ---------------------- #
# PostgreSQL connection config
db_config = {
    'database': 'baxterdb',        # Replace with your database name
        'user': 'baxterdev',        # Replace with your username
        'password': 'Password123',# Replace with your password
        'host': 'db',        # Use IP or host if not local
        'port': '5432',
        #"database": "BaxterDev"
}
table_name = "appendix_b_p2_conversion"
output_csv_path = Path("Appendix_B.csv")
 
# Rules: (CSV match column, JSONL path, JSONL match key, JSONL value key, CSV update column)
update_rules = [
    ("critical_qualitative", "therapy_ocurrences.jsonl", "Therapy Occurrences", "Qualitative", "critical_semi_quantitative"),
    ("moderate_qualitative", "therapy_ocurrences.jsonl", "Therapy Occurrences", "Qualitative", "moderate_semi_quantitative"),
    ("minor_qualitative", "therapy_ocurrences.jsonl", "Therapy Occurrences", "Qualitative", "minor_semi_quantitative"),
    ("critical", "Pharm_conversions.jsonl", "Individual Residual Risk", "Critical", "critical_pharm_qualitative"),
    ("moderate", "Pharm_conversions.jsonl", "Individual Residual Risk", "Moderate", "moderate_pharm_qualitative"),
    ("minor", "Pharm_conversions.jsonl", "Individual Residual Risk", "Minor", "minor_pharm_qualitative"),
]
# ---------------------------------------------------- #
 
jsonl_cache = {}
 
def load_jsonl(path: Path, key_field: str, value_field: str):
    ranges = []
    exacts = {}
 
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                obj = json.loads(line)
                raw_key = obj.get(key_field)
                value = obj.get(value_field)
                if not raw_key or not value:
                    continue
 
                key_str = str(raw_key).strip().replace('–', '-').replace('—', '-').replace('−', '-')
                value_str = str(value).strip()
 
                if key_str.replace('.', '', 1).isdigit() or '-' in key_str or ' - ' in key_str:
                    if '-' in key_str or ' - ' in key_str:
                        try:
                            parts = key_str.replace(' - ', '-').split('-')
                            if len(parts) == 2:
                                low, high = map(lambda x: int(float(x.strip())), parts)
                                ranges.append((low, high, value_str))
                        except ValueError:
                            continue
                    else:
                        try:
                            num = int(float(key_str))
                            ranges.append((num, num, value_str))
                        except ValueError:
                            continue
                else:
                    exacts[key_str.lower()] = value_str
            except json.JSONDecodeError:
                continue
 
    lookup = {
        "ranges": ranges,
        "exact": exacts
    }
    jsonl_cache[(str(path), key_field, value_field)] = lookup
    return lookup
 
def update_dataframe(df: pd.DataFrame, lookup: dict, match_column: str, update_column: str):
    for idx, row in df.iterrows():
        val = row.get(match_column)
 
        if pd.isnull(val):
            continue
 
        try:
            num = int(float(val))
            for low, high, result in lookup["ranges"]:
                if low <= num <= high:
                    df.at[idx, update_column] = result
                    break
            else:
                raise ValueError
        except (ValueError, TypeError):
            key = str(val).strip().lower()
            if key in lookup["exact"]:
                df.at[idx, update_column] = lookup["exact"][key]
 
    return df
 
def conversion():
    # Create PostgreSQL connection string
    conn_str = f"postgresql://{db_config['user']}:{db_config['password']}@" \
               f"{db_config['host']}:{db_config['port']}/{db_config['database']}"
 
    # Connect and load the table into a DataFrame
    engine = create_engine(conn_str)
    df = pd.read_sql(f"SELECT * FROM {table_name}", con=engine)
 
    for match_col, jsonl_file, jsonl_key, jsonl_value_key, update_col in update_rules:
        print(f"🔍 Updating {match_col} → {update_col} using {jsonl_file}")
        lookup = load_jsonl(Path(jsonl_file), jsonl_key, jsonl_value_key)
        df = update_dataframe(df, lookup, match_col, update_col)
 
    df.to_csv(output_csv_path, index=False)
    print(f"✅ Updated CSV saved to: {output_csv_path}")
 
if __name__ == "__main__":
    conversion()