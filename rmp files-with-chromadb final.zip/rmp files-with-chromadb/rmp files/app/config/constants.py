from .config_loader import ConfigLoader

config = ConfigLoader().config

# --- Configuration ---
OLLAMA_URL = config["embeddings"]["ollama"]["base_url"]
EMBED_MODEL = config["embeddings"]["ollama"]["model"]

CHROMA_HOST = config["storage"]["chroma"]["host"]
CHROMA_PORT = config["storage"]["chroma"]["port"]
COLLECTION_NAME = config["storage"]["chroma"]["collection_name"]
CHUNK_SIZE = config["storage"]["chunking"]["size"]
CHUNK_OVERLAP = config["storage"]["chunking"]["overlap"]

FM_MODEL = config["llms"]["ollama"]["model"]
OPENAI_FM_MODEL = config["llms"]["openai"]["model"]
OPENAI_BASE_URL = config["llms"]["openai"]["base_url"]
OPENAI_API_KEY = config["llms"]["openai"]["api_key"]

MAX_RESULTS = config["generation"]["max_results"]
TEMPERATURE = config["generation"]["temperature"]
MAX_TOKENS = config["generation"]["max_tokens"]

UPLOAD_FOLDER = config["data"]["upload_folder"]
ARCHIVE_FOLDER = config["data"]["archive_folder"]
INPUT_TEMPLATE_FOLDER = config["data"]["input_template_folder"]
DOWNLOAD_TEMPLATE_FOLDER = config["data"]["download_template_folder"]

LANGSMITH = config.get("langsmith", {})
