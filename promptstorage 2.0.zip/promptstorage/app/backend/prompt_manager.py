from fastapi import APIRouter, Request, Form, Query
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, Text, select, and_
import os
router = APIRouter()

templates = Jinja2Templates(directory="templates")

DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")  # use 'db' if running inside container
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

#DATABASE_URL = "postgresql://baxterdev:Password123@localhost:5432/baxterdb"
engine = create_engine(DATABASE_URL)
metadata = MetaData()

prompts = Table(
    "prompts",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("prompt_name", String(100)),
    Column("set_name", String(100)),
    Column("document_name", String(100)),
    Column("document_alias_name", String(100)),
    Column("prompt_text", Text)
)

metadata.create_all(engine)

@router.get("/")
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@router.get("/file")
def home(request: Request):
    return templates.TemplateResponse("file_repositary.html", {"request": request})


@router.get("/prompts", response_class=HTMLResponse)
async def prompt_tabs(request: Request):
    with engine.connect() as conn:
        result = conn.execute(select(prompts)).fetchall()
        sets = conn.execute(select(prompts.c.set_name).distinct()).scalars().all()
        docs = conn.execute(select(prompts.c.document_name).distinct()).scalars().all()

        set_doc_map = {}
        rows = conn.execute(select(prompts.c.set_name, prompts.c.document_name)).fetchall()
        for set_name, doc_name in rows:
            set_doc_map.setdefault(set_name, set()).add(doc_name)

    return templates.TemplateResponse("prompt_tabs.html", {
        "request": request,
        "prompts": result,
        "sets": sets,
        "docs": docs,
        "set_doc_map": dict((k, list(v)) for k, v in set_doc_map.items()),
    })

@router.get("/create", response_class=HTMLResponse)
async def create_prompt_form(request: Request):
    return templates.TemplateResponse("create_prompt3.html", {"request": request})

@router.get("/createnew", response_class=HTMLResponse)
async def create_prompt_form(request: Request):
    return templates.TemplateResponse("createnew.html", {"request": request})

@router.post("/save-prompt", response_class=HTMLResponse)
async def save_prompt(request: Request, prompt_name: str = Form(...), set_name: str = Form(...),
                      document_name: str = Form(...), document_alias_name: str = Form(...),
                      prompt_text: str = Form(...)):
    with engine.begin() as conn:
        conn.execute(prompts.insert().values(
            prompt_name=prompt_name,
            set_name=set_name,
            document_name=document_name,
            document_alias_name=document_alias_name,
            prompt_text=prompt_text
        ))
    return templates.TemplateResponse("create_prompt3.html", {
        "request": request,
        "message": "✅ Prompt saved successfully!"
    })

@router.get("/view-prompts", response_class=HTMLResponse)
async def view_prompts(request: Request, set_filter: str = "", doc_filter: str = "", message: str = Query(default="")):
    with engine.connect() as conn:
        query = select(prompts)
        if set_filter and doc_filter:
            query = query.where(and_(prompts.c.set_name == set_filter, prompts.c.document_name == doc_filter))
        elif set_filter:
            query = query.where(prompts.c.set_name == set_filter)
        elif doc_filter:
            query = query.where(prompts.c.document_name == doc_filter)

        result = conn.execute(query).fetchall()
        sets = conn.execute(select(prompts.c.set_name).distinct()).scalars().all()
        docs = conn.execute(select(prompts.c.document_name).distinct()).scalars().all()

        set_doc_map = {}
        rows = conn.execute(select(prompts.c.set_name, prompts.c.document_name)).fetchall()
        for set_name, doc_name in rows:
            set_doc_map.setdefault(set_name, set()).add(doc_name)

    return templates.TemplateResponse("view_prompts2.html", {
        "request": request,
        "prompts": result,
        "set_filter": set_filter,
        "doc_filter": doc_filter,
        "sets": sets,
        "docs": docs,
        "set_doc_map": dict((k, list(v)) for k, v in set_doc_map.items()),
        "message": message
    })

@router.get("/edit/{prompt_id}", response_class=HTMLResponse)
async def edit_prompt(request: Request, prompt_id: int):
    with engine.connect() as conn:
        prompt = conn.execute(select(prompts).where(prompts.c.id == prompt_id)).first()
    if not prompt:
        return HTMLResponse(content="❌ Prompt not found", status_code=404)
    return templates.TemplateResponse("edit_prompt.html", {"request": request, "prompt": prompt})

@router.post("/update/{prompt_id}", response_class=HTMLResponse)
async def update_prompt(request: Request, prompt_id: int,
                        prompt_name: str = Form(...),
                        set_name: str = Form(...),
                        document_name: str = Form(...),
                        document_alias_name: str = Form(...),
                        prompt_text: str = Form(...)):
    with engine.begin() as conn:
        conn.execute(prompts.update().where(prompts.c.id == prompt_id).values(
            prompt_name=prompt_name,
            set_name=set_name,
            document_name=document_name,
            document_alias_name=document_alias_name,
            prompt_text=prompt_text
        ))
    return RedirectResponse(url="/view-prompts?message=Prompt+updated+successfully", status_code=303)

@router.get("/delete/{prompt_id}")
async def delete_prompt(prompt_id: int):
    with engine.begin() as conn:
        conn.execute(prompts.delete().where(prompts.c.id == prompt_id))
    return RedirectResponse(url="/view-prompts?message=Prompt+deleted+successfully", status_code=303)
