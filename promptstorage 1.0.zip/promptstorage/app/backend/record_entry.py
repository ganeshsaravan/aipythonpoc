from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, MetaData, select, insert, update, delete, Boolean, Integer, String, Text,text
from starlette.status import HTTP_303_SEE_OTHER
from sqlalchemy.exc import IntegrityError
import os
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# DB connection string
DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "db")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

engine = create_engine(DATABASE_URL)
templates = Jinja2Templates(directory="templates")
router = APIRouter()


# =======================
# Helper Functions
# =======================

def get_metadata():
    metadata = MetaData()
    metadata.reflect(bind=engine)
    return metadata


def get_table(table_name: str):
    metadata = get_metadata()
    return metadata.tables.get(table_name)


def get_table_map():
    metadata = get_metadata()
    return {
        "master": get_table("Master_Input_JSON_Table"),
        "group": get_table("Group_Table"),
        "link": get_table("Link_Table"),
    }


def get_primary_key_column(table):
    if "id" in table.columns:
        return table.columns["id"]
    pks = list(table.primary_key.columns)
    if not pks:
        raise Exception(f"Table {table.name} has no primary key")
    return pks[0]


def convert_form_value(value: str, column):
    """
    Convert form string value to correct Python type based on column type.
    """
    if value == "NULL":
        return None

    if isinstance(column.type, Boolean):
        return value.lower() in ("true", "1", "on")
    elif isinstance(column.type, Integer):
        try:
            return int(value)
        except (ValueError, TypeError):
            raise ValueError(f"Cannot convert '{value}' to integer for column '{column.name}'")
    elif isinstance(column.type, (String, Text)):
        return value
    return value

def fix_sequence_for_table(table_name: str):
    sequence_sql = f"""
        SELECT setval(pg_get_serial_sequence('"{table_name}"', 'id'), 
                      (SELECT COALESCE(MAX(id), 1) FROM "{table_name}"));
    """
    with engine.connect() as conn:
        conn.execute(text(sequence_sql))
        logger.info(f"Fixed sequence for table: {table_name}")

# =======================
# Routes
# =======================

@router.get("/data/{table_name}")
def view_table(request: Request, table_name: str, view_all: bool = False):
    table_map = get_table_map()
    table = table_map.get(table_name)
    if table is None:
        raise HTTPException(status_code=404, detail="Invalid table name")

    with engine.connect() as conn:
        stmt = select(table).limit(None if view_all else 5)
        result = conn.execute(stmt)
        rows = result.fetchall()
        columns = list(table.columns.keys())

    pk_col = get_primary_key_column(table)
    default_cols = ['id', 'documentid', 'document_type', 'question', 'prompt_template']

    return templates.TemplateResponse("view_table.html", {
        "request": request,
        "rows": rows,
        "columns": columns,
        "default_columns_to_show": [c for c in default_cols if c in columns],
        "primary_key_col_name": pk_col.name,
        "table_name": table_name,
        "view_all": view_all,
        "all_table_names": list(table_map.keys()),
    })


@router.get("/data/{table_name}/add")
def add_form(request: Request, table_name: str):
    table_map = get_table_map()
    table = table_map.get(table_name)
    if table is None:
        raise HTTPException(status_code=404, detail="Invalid table name")

    pk_col = get_primary_key_column(table)
    columns = [col.name for col in table.columns if col.name != pk_col.name]
    return templates.TemplateResponse("add_record.html", {
        "request": request,
        "columns": columns,
        "table_name": table_name,
    })


@router.post("/data/{table_name}/add")
async def add_record(request: Request, table_name: str):
    table = get_table_map().get(table_name)
    if table is None:
        return RedirectResponse(url="/", status_code=HTTP_303_SEE_OTHER)

    pk_col = get_primary_key_column(table)
    form = await request.form()
    logger.info(f"Form data received for ADD in {table_name}: {dict(form)}")

    values = {}
    for key, value in form.items():
        if key == pk_col.name:
            continue
        column = table.columns.get(key)
        if column is None:
            values[key] = value
        else:
            values[key] = convert_form_value(value, column)

    try:
        with engine.begin() as conn:
            conn.execute(insert(table).values(values))
    except IntegrityError as e:
        if 'duplicate key' in str(e):
            fix_sequence_for_table(table.name)
        logger.error(f"Insert error: {e}")
        return RedirectResponse(url=f"/data/{table_name}/add", status_code=HTTP_303_SEE_OTHER)

    return RedirectResponse(url=f"/data/{table_name}", status_code=HTTP_303_SEE_OTHER)


@router.get("/data/{table_name}/edit/{record_id}")
def edit_form(request: Request, table_name: str, record_id: int):
    table = get_table_map().get(table_name)
    if table is None:
        raise HTTPException(404)

    pk_col = get_primary_key_column(table)
    with engine.connect() as conn:
        result = conn.execute(select(table).where(pk_col == record_id))
        row = result.fetchone()

    if not row:
        raise HTTPException(404, detail="Record not found")

    return templates.TemplateResponse("edit_record.html", {
        "request": request,
        "row": dict(row._mapping),
        "table_name": table_name,
        "primary_key": pk_col.name,
        "record_id": record_id,
    })


@router.post("/data/{table_name}/edit/{record_id}")
async def edit_record(request: Request, table_name: str, record_id: int):
    table = get_table_map().get(table_name)
    if table is None:
        return RedirectResponse(url="/", status_code=HTTP_303_SEE_OTHER)

    pk_col = get_primary_key_column(table)
    form = await request.form()
    logger.info(f"Form data received for EDIT (ID={record_id}): {dict(form)}")

    values = {}
    for key, value in form.items():
        if key == pk_col.name:
            continue
        column = table.columns.get(key)
        if column is None:
            values[key] = value
        else:
            values[key] = convert_form_value(value, column)

    try:
        with engine.begin() as conn:
            stmt = update(table).where(pk_col == record_id).values(values)
            conn.execute(stmt)
    except IntegrityError as e:
        if 'duplicate key' in str(e):
            fix_sequence_for_table(table.name)
        logger.error(f"Update error: {e}")
        return RedirectResponse(url=f"/data/{table_name}", status_code=HTTP_303_SEE_OTHER)

    return RedirectResponse(url=f"/data/{table_name}", status_code=HTTP_303_SEE_OTHER)



@router.get("/data/{table_name}/delete/{record_id}")
def delete_record(request: Request, table_name: str, record_id: int):
    table_map = get_table_map()
    table = table_map.get(table_name)
    if table is None:
        return RedirectResponse(url="/", status_code=HTTP_303_SEE_OTHER)

    pk_col = get_primary_key_column(table)
    pk_col_name = pk_col.name

    try:
        with engine.begin() as conn:
            stmt = delete(table).where(table.c[pk_col_name] == record_id)
            result = conn.execute(stmt)
            logger.info(f"Deleted {result.rowcount} row(s) with ID={record_id}")
    except Exception as e:
        logger.error(f"Error deleting record {record_id} from {table_name}: {e}")
        return RedirectResponse(url=f"/data/{table_name}", status_code=HTTP_303_SEE_OTHER)

    return RedirectResponse(url=f"/data/{table_name}", status_code=HTTP_303_SEE_OTHER)
